# Workup Extensions — CC AQ-Specific Sections

The parent skill's `workup_template.md` handles the generic paper
workup. This sub-skill appends the following sections, in this order,
after "Connections to my work" and before "Personal notes."

## Section 1: How this paper informs H1-H4 + our RQs

Fill in one sentence per hypothesis / RQ, or `n/a` if the paper
truly doesn't touch it. This is the highest-value section — do not
skip.

```markdown
## How this paper informs H1-H4 + our RQs

- **H1 (direction > concentration).** [1 sentence]
- **H2 (top RF features).** [1 sentence]
- **H3 (SO₂ ~ wind; O₃ ~ photochemistry).** [1 sentence]
- **H4 (AQI classifier).** [1 sentence]
- **Primary RQ (RF accuracy).** [1 sentence]
- **Secondary RQ (seasonal + yearly variation).** [1 sentence]
- **Tabled future extension (health outcomes).** [1 sentence, or
  "n/a — no health outcomes in this paper"]
```

See `hypothesis_mapping.md` for the category → hypothesis mapping.

## Section 2: Integration candidates

Every boxed annotation (`[integration:<tag>]`) from the annotated
PDF appears here. If no boxes were drawn, write "None — nothing in
this paper's figures/tables translates directly to our planned
Figs 1-6 or tables."

```markdown
## Integration candidates

- **Fig N (source)** — `[integration:<tag>] (<sub-tag>)` — what to
  reuse and why.
- **Table N (source)** — `[integration:<tag>]` — what to reuse.
- ...
```

## Section 3: Where to cite in our proposal / manuscript

Tie the paper to specific sections of our own writing. This is what
makes the workup pay back later.

```markdown
## Where to cite in our proposal / manuscript

- **Study Rationale.** [Y/N + one-line reason if Y]
- **Literature Gap Addressed.** [Y/N + one-line reason if Y]
- **Methods — RF choice.** [Y/N + one-line reason if Y]
- **Methods — variable choice.** [Y/N + one-line reason if Y]
- **Discussion — sea-breeze framing.** [Y/N + one-line reason if Y]
- **Discussion — refinery point-source framing.** [Y/N + one-line
  reason if Y]
- **Discussion — comparison paper.** [Y/N + one-line reason if Y]
- **Discussion — future health extension.** [Y/N + one-line reason
  if Y]
- **Supplementary — method-code / instrument justification.** [Y/N]
```

## Section 4: Zotero add

If the paper isn't already in the shared Zotero collection, mark
here so you remember to add it.

```markdown
## Zotero add

- [ ] Not yet in the shared collection — **add**.
- [x] Already in the shared collection.

**Collection folder:** [e.g. "Refinery / point-source health" or
"RF / ML AQ methods" or "Sea breeze"]
```

## Section 5: Follow-up notes to teammates

If the paper is directly relevant to Jasmine's or Manasa's ownership
area, flag it here.

```markdown
## Follow-up notes to teammates

- **@Jasmine:** [reason to ping — e.g. "this paper's Fig 4 is a
  cleaner version of the pollution rose we discussed at 2026-09-20"]
- **@Manasa:** [reason to ping]
- **@Dr. Melaram:** [reason to escalate to PI]
```

## Section 6: Meeting-notes cross-reference

If a decision, comment, or action item from a specific team meeting
is directly informed by this paper, cross-reference it.

```markdown
## Meeting-notes cross-reference

- **[YYYY-MM-DD meeting](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/YYYY-MM-DD/)** — [decision / question this paper resolves or opens]
```

## Rendering order in the final workup doc

Full order of sections in the final `.md` output:

1. Header (citation, DOI, takeaway, legend) — from parent template.
2. Study aim — from parent template.
3. Definitions — from parent template.
4. Methods — from parent template.
5. Key findings — from parent template.
6. Notable equations / figures / tables (including
   **Integration candidates** subsection from this sub-skill) —
   from parent template.
7. Prior work threads — from parent template.
8. Limitations — from parent template.
9. Questions raised — from parent template.
10. Connections to my work — from parent template.
11. **How this paper informs H1-H4 + our RQs** ← this sub-skill
12. **Where to cite in our proposal / manuscript** ← this sub-skill
13. **Zotero add** ← this sub-skill
14. **Follow-up notes to teammates** ← this sub-skill
15. **Meeting-notes cross-reference** ← this sub-skill
16. Personal notes — from parent template (always last).

## What NOT to include in the workup

Even in the sub-skill:

- Do NOT re-copy the abstract verbatim.
- Do NOT paste a page-by-page transcript.
- Do NOT include a section that would just say "n/a" — leave the
  section out entirely if truly empty.

Aim for 2-3 pages max for a typical 8-page paper (parent's 1-2
page target + this sub-skill's ~1 page of extensions).
