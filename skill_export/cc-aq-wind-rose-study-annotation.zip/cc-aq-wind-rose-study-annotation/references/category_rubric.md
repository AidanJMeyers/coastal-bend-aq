# Category Rubric — CC AQ Wind Rose Study

The 8 default colors get **repurposed** for this study so every
highlight maps directly to a hypothesis, research question, or a
specific methodological anchor of our design.

Overlap with parent-skill defaults noted per category.

## 🟨 Yellow — Refinery / point-source directional evidence

**Highlight anything that:**

- Uses **wind direction** as a component of exposure attribution
  (not just as a predictor of concentration).
- Attributes pollutant loads to a **specific industrial point source**
  (refinery, petrochemical plant, port complex, power station).
- Reports **downwind-vs-upwind concentration differences**.
- Describes **plume-tracking** or trajectory-based exposure
  characterization.

**Maps to:** H1 (direction > concentration), primary RQ.

**Why yellow:** the study's central axis. First color to reach for.

## 🟩 Green — RF / ML methodology

**Highlight anything that:**

- Describes **Random Forest** application (or gradient-boosting, XGBoost,
  bagged trees) to air-quality data.
- Reports **feature-importance** results for meteorological predictors.
- Uses **K-fold cross-validation** or **stacked models**.
- Documents **hyperparameter choices** for tree-based ML on
  atmospheric data.
- Reports **RF performance metrics** (R², RMSE, MAE) with
  meteorological features.

**Maps to:** Methods section, H2 (top RF features hypothesis).

**Overrides default:** yes — parent skill's green (methods) becomes
more specific here. General methods paragraphs unrelated to
ML/AQ can still be marked green, but the primary use is
ML-methodology anchoring.

## 🟧 Orange — Sea-breeze / coastal meteorology

**Highlight anything that:**

- Documents **sea-breeze circulation**, land-sea breeze,
  bay-breeze effects on pollutant transport.
- Reports **Gulf coast** or Texas coastal meteorology.
- Describes **recirculation events** or diurnal reversals near a
  coastline.
- Uses **boundary-layer dynamics** relevant to coastal environments.
- Notes **seasonal wind-pattern shifts** in coastal areas.

**Maps to:** H1 (sea breeze anchors direction), secondary RQ
(seasonal + yearly directional variation).

**Why orange:** distinguishes coastal-meteorology signal from the
generic "methods" bucket.

## 🟪 Purple — SO₂ / O₃ / PM2.5 chemistry + monitoring

**Highlight anything that:**

- Explains **SO₂ transport-controlled behavior** (primary pollutant,
  short atmospheric lifetime).
- Explains **O₃ photochemical formation** (secondary pollutant, solar
  irradiance + temperature dependence, NOₓ + VOC precursors).
- Discusses **PM2.5 sources and speciation** (sulfate, nitrate,
  organic carbon, sea salt) in coastal/industrial contexts.
- Documents **FRM/FEM instrumentation** or **method-code semantics**
  (BAM 1020, TEOM, UV fluorescence for SO₂, UV photometric for O₃).
- Reports **method-code changes** and their effect on concentration
  time series.

**Maps to:** H3 (pollutant-specific predictor dominance), pollutant
deep-dive updates.

**Overrides default:** yes — replaces "definitions/terms" with
chemistry/monitoring content.

## 🟥 Red — Limitations / caveats

**Highlight anything that:**

- **Author-flagged limitation.**
- **Sample restriction** or generalizability warning.
- **Unmeasured confounder** in a health-outcome study.
- **Method-code transition** the authors did not address.
- **Missingness / imputation strategy** — especially if under-reported
  (per our 2026-08-12 imputation-transparency rule).
- **Reader-flagged caveat** (things the authors ignored that we
  wouldn't).

**Maps to:** our own manuscript's limitations section; also feeds the
"gaps we're addressing" list in the novelty case.

**Same as default palette.**

## 🟦 Blue — Health-outcome findings (tabled for now)

**Highlight anything that:**

- Reports **respiratory / cardiovascular health outcomes** near
  refineries or industrial point sources.
- Uses **ED visit** or **hospitalization** data as a health target.
- Documents **BREATHE-CC-relevant pediatric respiratory work**.
- Uses **ICD codes** (J45.x asthma, J44.x COPD, J20 bronchitis, I20-I25
  cardiovascular) with air-quality exposures.

**Maps to:** the **tabled** future health-outcome extension. Keep
highlighting — future-us will thank present-us when the extension
gets un-tabled.

**Overrides default:** yes — replaces "numbers/data" with
health-outcome content. Numeric findings are still fair game for
blue.

## 🟫 Brown — Prior work / citations to chase

**Highlight anything that:**

- **Cites a paper we should read.** Especially: prior directional
  exposure studies, refinery health studies, or ML-air-quality
  reviews.
- **Cites a foundational paper we haven't yet cited** in our
  proposal.
- **Cites the Melaram Lab's own prior work** (Sanchez-Warren 2026,
  etc.) — worth noting where downstream work builds on ours.

**Maps to:** literature review + Zotero adds.

**Same as default palette.** Especially valuable for the paper's
introduction — many good citations to chase live there.

## 🩶 Gray — Questions raised / gaps we could fill

**Highlight anything that:**

- **Explicit gap statement** by the paper's authors ("future work
  should…", "this study did not address…").
- **Implicit gap** the reader notices (e.g., a paper does regional
  wind but doesn't do point-source-anchored wind).
- **Contradiction** between the paper's findings and other
  literature (worth pursuing).
- **Question you (the reader) want to ask the authors.**

**Maps to:** our novelty case, our discussion positioning, our
"comparison paper" list.

**Same as default palette.** Pair with a margin sticky note stating
the question or gap succinctly.

## Choosing between overlapping categories

If a span fits two categories, pick the one that scores highest on:

1. **Direct hypothesis mapping.** If yellow (directional evidence)
   also touches green (RF methods) — pick yellow. Hypothesis mapping
   beats generic methodology.
2. **Actionability.** If red (limitation) also touches gray
   (question) — pick gray if the question suggests a paper we
   could write; red if it's a limitation we should note in our own
   discussion.
3. **Recall for a future reader.** Which color would you rather see
   when you skim the annotated PDF 3 months from now?

## What not to highlight

- **Author affiliations, acknowledgments, funding statements.** Not
  useful.
- **Standard boilerplate methods sentences** ("data were analyzed
  using R version …") unless the version matters.
- **Every citation** — brown is for citations *worth chasing*, not
  every citation in the paper.
- **Every result number** — blue is for headline / effect-size
  numbers, not every subsidiary p-value.

Aim for **~1 highlight per column-inch** at maximum. Sparse
annotation is more useful than dense annotation.
