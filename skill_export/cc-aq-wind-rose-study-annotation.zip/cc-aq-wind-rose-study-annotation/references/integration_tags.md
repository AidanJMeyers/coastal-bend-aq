# Integration Tags for Boxed Figure/Table Annotations

When a figure or table in the source paper is a **direct integration
candidate** for one of our own planned figures or tables, box it in
dark green (`#1B5E20`, 1.5 pt stroke) per the parent skill and add
one of these `[integration:<tag>]` markers to the margin caption.

## Our planned figures (from the proposal draft)

Recap:

- **Fig 1** — Map of Refinery Row + monitoring network.
- **Fig 2** — Data-availability heat map (site × pollutant × year).
- **Fig 3** — HYSPLIT backward trajectories per season.
- **Fig 4** — Seasonal pollution + wind roses.
- **Fig 5** — Observed vs predicted pollutant concentrations.
- **Fig 6** — Random-Forest feature importance.

## Integration tag catalog

Use exactly one tag per boxed annotation. Sub-tag detail can go
after the tag in parentheses.

| Tag | Use when source paper shows | Our figure this informs |
|---|---|---|
| `[integration:fig1-site-map]` | Any map of monitoring sites overlaid with pollution sources / refineries / port complex / population density | Fig 1 |
| `[integration:fig2-availability-heatmap]` | Any site × time-period × pollutant / measurement heat map, especially with color-coded completeness | Fig 2 |
| `[integration:fig3-hysplit-trajectories]` | HYSPLIT / NOAA READY back-trajectory maps, trajectory-frequency surfaces, cluster-analysis plots | Fig 3 |
| `[integration:fig4-pollution-rose]` | Pollution roses, wind roses, `openair::pollutionRose` output, wind-frequency polar plots, bivariate polar plots | Fig 4 |
| `[integration:fig5-obs-pred-scatter]` | Observed-vs-predicted scatter with 1:1 line, R² / MAE / RMSE inset, colored by season or pollutant | Fig 5 |
| `[integration:fig6-feature-importance]` | RF / gradient-boost feature-importance bar charts, SHAP summary plots, permutation-importance rankings | Fig 6 |
| `[integration:variables-table]` | Variables / operational-definitions tables — especially with type + unit + source columns per row | Table 2 (variables dictionary) |
| `[integration:method-code-table]` | Instrument / method-code / AQS parameter tables — especially with per-site coverage windows | Table 6 (instrument methods) |
| `[integration:naaqs-history-table]` | NAAQS revision history tables, AQI-band definitions with breakpoints | Supplementary table |
| `[integration:hysplit-frequency-legend]` | HYSPLIT trajectory-frequency color scale legends (we want consistent scales across seasons) | Fig 3 colorbar |

## When to use no tag vs one of the above

**Use a tag** when the boxed figure/table is a candidate to inform
our own Fig 1-6 or one of our tables. That is the whole point of
the boxed annotation.

**Do not use a tag** — do not box at all — for figures that are:

- Interesting to look at but not translatable to our planned figures.
- Aesthetically appealing but methodologically different.
- Show a result but not a format we can reuse.

## Sub-tag detail

If you want to note more specifically what to reuse, append after
the tag in parentheses:

- `[integration:fig4-pollution-rose] (paneling by season)` — reuse
  the seasonal facet layout.
- `[integration:fig1-site-map] (basemap choice)` — reuse the Esri
  Gray Canvas basemap decision.
- `[integration:fig6-feature-importance] (color-by-pollutant
  legend)` — reuse the color legend that keeps pollutant identity
  visible.
- `[integration:variables-table] (add "derived from" column)` —
  extend our variables table with a "derived from" column following
  this paper's example.

## Adding a new integration tag

If a paper shows a figure/table format we want to reuse but no tag
in the catalog above fits, add one:

1. Coin a short kebab-case tag: `[integration:<what-figure-or-table>]`.
2. Add it to the table in this file with a use-when description +
   the target of our figure or table.
3. Commit the sub-skill update; note in the pipeline changelog if
   the tag survives review.

Keep the catalog under ~15 tags total. If it grows larger, the
categorisation is fragmenting and we're probably over-boxing.

## Interaction with the workup document

Every boxed annotation with an integration tag must also appear in
the workup doc's **"Notable equations, figures, tables →
Integration candidates"** subsection. Format:

```markdown
- **Fig N (source paper)** — `[integration:<tag>] (<sub-tag>)`
  — what to reuse and why.
```

Example:

> - **Fig 3 (Bralić 2024)** — `[integration:fig4-pollution-rose]
>   (paneling by season)` — clean 4-panel seasonal facet layout
>   with shared radial axis; we can adopt directly.
