# Worked Example — Annotating Smargiassi et al. 2009 for the CC AQ Study

An end-to-end walkthrough showing how the parent skill's workflow
and this sub-skill's rubric produce an annotated PDF + workup doc
for a directly-relevant prior study.

## The paper

**Smargiassi, A., Kosatsky, T., Hicks, J., Plante, C., Armstrong, B.,
Villeneuve, P.J., & Goudreau, S. (2009).** *Risk of Asthmatic
Episodes in Children Exposed to Sulfur Dioxide Stack Emissions from
a Refinery Point Source in Montreal, Canada.* **Environmental Health
Perspectives**, 117(4), 653-659.
DOI: [10.1289/ehp.11868](https://doi.org/10.1289/ehp.11868).

Chosen because it's the canonical prior wind-direction-weighted
refinery health study — the methodological blueprint for our
tabled health-outcome extension, and a natural citation for our
Study Rationale + Discussion.

## Step 0 — Setup

- **PDF MCP loaded:** `mcp__PDF_Tools__*` (assumed).
- **Sub-skill loaded:** yes, `cc-aq-wind-rose-study-annotation`.
- **Parent loaded:** `scientific-paper-annotation`.

## Step 1 — Acquire

Fetch via DOI → open with `mcp__PDF_Tools__display_pdf`. Capture
metadata: 12 pages, Environmental Health Perspectives, 2009.

## Step 2 — Read pass 1 (10 min)

**Study aim (mental note):** does wind-direction-weighted exposure
from a Montreal refinery predict childhood asthma more than plain
distance?

**Methods (one sentence):** case-crossover of ED visits, exposure
= wind-vector-weighted proximity from refinery stacks.

**Main finding (one sentence):** wind-direction-weighted exposure
significantly predicted asthma-ED visits; simple distance did not.

**Three things worth remembering:**

- Wind vector approach beats distance-alone (H1 → H1 analog).
- Case-crossover design controls for time-invariant confounders
  cleanly.
- SO₂ is the pollutant; refinery is the point source (perfect
  analog).

## Step 3 — Categorize

**Expected categories** (from `category_rubric.md` archetype
"refinery-adjacent health study"): 🟨 + 🟦 + 🟥 dominant; 🟩 + 🩶
secondary; 🟪 for SO₂ chemistry; 🟫 for prior refinery-health
citations.

**Integration candidates pre-identified:**

- Fig 1 (site map + refinery + monitor rings) — box with
  `[integration:fig1-site-map]`.
- Fig 3 (wind-vector-weighted exposure metric visualisation) — box
  with `[integration:fig4-pollution-rose] (weighting scheme
  transfer)`.
- Table 1 (variables + operational definitions) — box with
  `[integration:variables-table]`.

## Step 4 — Highlight pass

Sample of what lands where (abbreviated for space):

- **Abstract:** yellow highlight on wind-direction-weighted vs
  distance-only sentence; blue highlight on the OR + CI headline
  numbers; brown on the two citations they use for
  distance-only-doesn't-work.
- **Intro §1:** brown on 4 prior citations of refinery-health
  literature; yellow on Smargiassi's own gap statement about
  directional exposure.
- **Methods:** green on case-crossover design paragraph; green on
  the wind-vector formula (specifically the formula sentence);
  purple on the "SO₂ as marker for refinery emissions" paragraph.
- **Results §Table 3:** blue on the effect sizes; orange on the
  effect-size direction sentence; red on the sample-size limitation.
- **Discussion:** gray on the "future work could extend to
  time-varying exposure" line; brown on the Cape Town refinery
  comparison; red on the generalizability limitations.

## Step 5 — Boxed figures/tables

Three boxes drawn:

- **Fig 1** — dark green 1.5 pt border + margin caption:
  `[integration:fig1-site-map] (refinery + monitors + city grid
  layout)`.
- **Fig 3** — `[integration:fig4-pollution-rose] (wind-vector
  exposure weighting)`.
- **Table 1** — `[integration:variables-table] (add "derived from"
  column)`.

## Step 6 — Legend (in workup doc)

| Color | Category | Count |
|---|---|---:|
| 🟨 Yellow | Refinery / point-source directional evidence | 4 |
| 🟩 Green | RF / ML methodology *(here: case-crossover methodology)* | 6 |
| 🟪 Purple | SO₂ chemistry + monitoring | 2 |
| 🟥 Red | Limitations | 3 |
| 🟦 Blue | Health-outcome findings | 5 |
| 🟫 Brown | Prior work / citations to chase | 7 |
| 🩶 Gray | Questions raised / gaps | 2 |
| 🟩 Dark green box | Integration candidate | 3 |

## Step 7 — Workup doc (excerpt)

Full workup would be 2-3 pages. Key sections excerpted below.

### Header

> **Citation.** Smargiassi et al. 2009. *Risk of Asthmatic Episodes in
> Children Exposed to Sulfur Dioxide Stack Emissions from a Refinery
> Point Source in Montreal, Canada.* Environ Health Perspect
> 117(4):653-659.
> **DOI.** <https://doi.org/10.1289/ehp.11868>
> **Read.** 2026-09-20.
> **Reader.** Aidan.
> **Sub-skill applied.** cc-aq-wind-rose-study-annotation
>
> **One-sentence takeaway.** Wind-vector-weighted refinery exposure
> significantly predicted childhood asthma ED visits in Montreal
> where simple distance did not — the canonical methodological
> blueprint for our own tabled health-outcome extension.

### Study aim

- Test whether a wind-direction-weighted exposure metric outperforms
  distance-only for predicting asthma ED visits among children
  living near a Montreal refinery.

### Methods

- Case-crossover design (each case is its own control on non-event
  days).
- Wind-vector-weighted exposure metric: distance × cosine of angle
  between residential position and wind direction, at each hour.
- Health data: pediatric ED visit records with residential postal
  codes, 5 years.
- SO₂ = marker pollutant for refinery emissions.

### Integration candidates

- **Fig 1 (Smargiassi 2009)** — `[integration:fig1-site-map]
  (refinery + monitors + city grid layout)` — the layout with the
  refinery centered + concentric rings for site coverage +
  a color-coded population density overlay is exactly the structure
  our Fig 1 wants. Adopt directly.
- **Fig 3 (Smargiassi 2009)** — `[integration:fig4-pollution-rose]
  (wind-vector exposure weighting)` — the visualisation of the
  cosine-weighted exposure scheme is a candidate for how we could
  render the Refinery-Row bearing variable graphically.
- **Table 1 (Smargiassi 2009)** — `[integration:variables-table]
  (add "derived from" column)` — their variables table has a
  "derived from" column that documents which raw measurements went
  into each derived variable; a good extension for our Table 2.

### How this paper informs H1-H4 + our RQs

- **H1 (direction > concentration).** Directly analogous: their
  wind-weighted metric outperformed distance-only, mirroring our
  H1 that direction beats concentration.
- **H2 (top RF features).** n/a — they used case-crossover, not RF.
- **H3 (SO₂ ~ wind; O₃ ~ photochemistry).** Confirms SO₂ as a good
  refinery marker; consistent with our H3 SO₂ side.
- **H4 (AQI classifier).** n/a.
- **Primary RQ (RF accuracy).** Methodological precedent for
  directional exposure attribution; not RF-specific.
- **Secondary RQ (seasonal + yearly variation).** They didn't
  stratify by season; a gap our study can address.
- **Tabled future extension (health outcomes).** This IS the
  blueprint. When the extension gets un-tabled, this paper's
  wind-vector formula is a candidate direct import.

### Where to cite in our proposal / manuscript

- **Study Rationale.** Y — cite for the SO₂-from-refinery-triggers-
  asthma claim.
- **Literature Gap Addressed.** Y — the small directional-exposure
  literature they represent.
- **Methods — variable choice.** Y — cite when introducing the
  Refinery-Row bearing variable.
- **Discussion — refinery point-source framing.** Y — cite as
  precedent.
- **Discussion — future health extension.** Y — cite as the model
  for how the extension would work.

### Zotero add

- [ ] Not yet in the shared collection — **add**.
- Collection folder: "Refinery / point-source health".

### Follow-up notes to teammates

- **@Jasmine:** the wind-vector-weighting scheme in Fig 3 is a
  direct precedent for our Refinery-Row bearing variable — worth a
  10-min read.
- **@Manasa:** their Table 1 "derived from" column is a small tweak
  we could add to our own variables table; low effort, useful.

### Meeting-notes cross-reference

- **[2026-07-15 meeting](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-07-15/)** — this paper is the "canonical prior wind-direction-weighted refinery health study" referenced in the meeting-notes discussion of prior work.
- **[2026-09-20 meeting](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-09-20/)** — the Refinery-Row proximity variable decision was informed by this exact paper's methodology.

## Time to complete

For this ~12-page methods-heavy paper, total time was ~80 minutes:
setup 3, pass 1 12, categorize 3, highlight 35, box 5, workup 22.
Slightly above the parent skill's 70-min estimate — a paper that
touches multiple hypotheses justifies a longer workup.
