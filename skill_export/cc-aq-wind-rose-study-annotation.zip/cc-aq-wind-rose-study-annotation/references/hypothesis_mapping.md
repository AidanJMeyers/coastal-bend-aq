# Hypothesis Mapping — Category → H1/H2/H3/H4 + RQs

Which highlight category supports which of our study's hypotheses or
research questions. Use this when writing the workup doc's "How this
paper informs H1-H4 + our figures" section.

## Our hypotheses (recap, from the proposal draft)

| # | Hypothesis (one-sentence) |
|---|---|
| **H1** | RF predicts pollutant *transport direction* more accurately than *concentration*, because Corpus Christi wind is remarkably constant. |
| **H2** | RF top features will be **season, wind speed, temperature**. |
| **H3** | SO₂ models dominated by **wind-derived predictors**; O₃ models dominated by **photochemical predictors** (solar irradiance, temperature). |
| **H4** *(exploratory)* | RF classifier performs defensibly across AQI bands, including on high-concentration days that pose greater public-health risk. |

## Our research questions

- **Primary.** How accurately can RF predict transport direction +
  concentration of SO₂, O₃, PM2.5 from routine meteorology in the
  CC Refinery-Row region, 2015-2025?
- **Secondary.** Do the resulting directional patterns vary
  systematically by season and year, and is that variation consistent
  with environmental control (sea-breeze / frontal reversal) of
  transport from Refinery Row?
- **Exploratory (H4).** AQI-band classifier for public-facing early
  warning.
- **Future (tabled).** Predicted pollutant transport patterns as
  input to respiratory health outcome prediction (BREATHE-CC).

## Category → Hypothesis / RQ mapping

Reading in reverse: when a highlight lands, this tells you which
of H1-H4 or which RQ it informs. Use for the workup doc's
"Connections to my work" section.

| Category (color) | Directly informs |
|---|---|
| 🟨 Yellow — refinery / point-source directional evidence | **H1** (direction accuracy), **Primary RQ** |
| 🟩 Green — RF / ML methodology | **H2** (feature ranking), **Primary RQ** (methods) |
| 🟧 Orange — sea-breeze / coastal meteorology | **H1** (why direction is predictable), **Secondary RQ** (seasonal variation) |
| 🟪 Purple — SO₂ / O₃ / PM2.5 chemistry + monitoring | **H3** (pollutant-specific predictor dominance) |
| 🟥 Red — limitations / caveats | Our own limitations section; **novelty case** (what other studies missed) |
| 🟦 Blue — health-outcome findings | **Future (tabled) extension**; not scored in current MS |
| 🟫 Brown — prior work / citations to chase | Literature review + citation graph |
| 🩶 Gray — questions raised / gaps | **Novelty case**; **comparison paper** positioning |

## Cross-checks per hypothesis

When finishing a workup, check whether the paper informs each
hypothesis. Write one sentence per row, or `n/a` if the paper
truly doesn't touch it.

```markdown
### How this paper informs H1-H4 + our RQs

- **H1 (direction > concentration).**
  [1 sentence — usually driven by yellow/orange highlights]
- **H2 (top RF features).**
  [1 sentence — usually driven by green highlights + Fig 6 boxes]
- **H3 (SO₂ ~ wind; O₃ ~ photochemistry).**
  [1 sentence — usually driven by purple highlights]
- **H4 (AQI classifier).**
  [1 sentence — usually only in AQI-focused papers]
- **Primary RQ (RF accuracy).**
  [1 sentence]
- **Secondary RQ (seasonal + yearly variation).**
  [1 sentence]
- **Tabled future extension (health outcomes).**
  [1 sentence if blue highlights present; else "n/a — no health
  outcomes in this paper"]
```

## Common paper archetypes + expected color mix

Quick prior about what a paper's highlight distribution will look
like, so you can spot when the categorisation is off.

| Paper archetype | Dominant colors | Secondary colors |
|---|---|---|
| Refinery-adjacent health study | 🟨 + 🟦 + 🟥 | 🟩 + 🩶 |
| Random-Forest / ML AQ methods paper | 🟩 + 🟧 (if it touches wind) | 🟨 + 🩶 |
| Sea-breeze / coastal meteorology | 🟧 + 🟪 (chemistry linkage) | 🟨 + 🟫 |
| SO₂ + refinery emissions inventory | 🟨 + 🟪 | 🟦 + 🟥 |
| Pollution-rose / `openair` methods | 🟩 + 🟨 | 🟪 + integration boxes on Figs 4 |
| Corpus Christi–specific prior work | 🟨 + 🟧 + 🟪 | 🟦 + 🟥 + 🩶 |
| BREATHE-CC / pediatric respiratory | 🟦 + 🟥 | 🟨 (if AQ exposure encoded) |

If your paper's highlight distribution is very different from its
archetype, take another pass — either you missed a category or you
applied one too generously.
