---
name: cc-aq-wind-rose-study-annotation
description: Sub-skill of scientific-paper-annotation. Provides Melaram Lab CC AQ Wind Rose Study-specific highlighting rubric that maps annotations to hypotheses H1-H4, the primary + secondary research questions, and the six planned manuscript figures. Load in tandem with scientific-paper-annotation when annotating any paper being read for the CC AQ / Coastal Bend / Refinery Row study — including air-quality methodology papers, sea-breeze / meteorological papers, refinery point-source health papers, Random-Forest / ML air-quality papers, pollution-rose / openair papers, and BREATHE-CC-adjacent respiratory-outcome papers. Triggers on "annotate for CC AQ", "annotate for the wind rose study", "annotate for refinery row", "annotate for Melaram Lab AQ", or when the parent skill is loaded and the paper's topic matches the study scope.
---

# CC AQ Wind Rose Study — Annotation Sub-skill

**Sub-skill of `scientific-paper-annotation`.** Load in tandem with
the parent skill whenever a paper is being annotated for the Melaram
Lab CC AQ Wind Rose Study.

## What this sub-skill does

- **Swaps in a study-specific highlighting rubric** — the 8 default
  colors get repurposed to map directly to H1-H4 hypotheses, the
  primary + secondary RQs, and the study's methodological anchors.
- **Adds `[integration:<tag>]` values** that name the six planned
  manuscript figures + variables tables — so when a paper's figure
  is boxed as an integration candidate, the tag says exactly which
  of our figures it would inform.
- **Extends the workup document** with a "How this paper informs
  H1-H4 + our figures" section.
- **Keeps the parent's boxed-figure convention** (1.5 pt dark green
  stroke) unchanged.

## Reference files

- [`references/category_rubric.md`](./references/category_rubric.md) —
  what to highlight in what color, for this study.
- [`references/hypothesis_mapping.md`](./references/hypothesis_mapping.md) —
  which highlight category supports which hypothesis / RQ.
- [`references/integration_tags.md`](./references/integration_tags.md) —
  the `[integration:<tag>]` catalog for boxed figures/tables.
- [`references/workup_extensions.md`](./references/workup_extensions.md) —
  the extra workup-doc sections this sub-skill appends.
- [`references/example_paper.md`](./references/example_paper.md) —
  worked example: annotating a directly-relevant paper (White et al.
  2009 or Smargiassi et al. 2009) end-to-end for this study.

## Category rubric (quick reference)

Full definitions in `references/category_rubric.md`.

| Color | Category | Maps to |
|---|---|---|
| 🟨 Yellow | **Refinery / point-source directional evidence** | H1 (direction > concentration), primary RQ |
| 🟩 Green | **RF / ML methodology** | Methods section, H2 (feature importance) |
| 🟧 Orange | **Sea-breeze / coastal meteorology** | H1, secondary RQ (seasonal patterns) |
| 🟪 Purple | **SO₂ / photochemistry of O₃ / PM2.5 chemistry** | H3 (pollutant-specific predictors) |
| 🟥 Red | **Limitations / caveats** | Discussion section, our own limitations mapping |
| 🟦 Blue | **Health-outcome findings** | Tabled future extension; keep for later |
| 🟫 Brown | **Prior work / citations to chase** | Literature review + zotero adds |
| 🩶 Gray | **Questions raised / gaps we could fill** | Novelty case, discussion positioning |

Plus **dark green box** on figures/tables that are integration
candidates for our planned Figs 1-6 or the variables table — see
`integration_tags.md` for the tag catalog.

## Boxed-annotation integration tags for this study

Full catalog in `references/integration_tags.md`. Quick reference:

- `[integration:fig1-site-map]` — refinery + monitor + met station
  maps
- `[integration:fig2-availability-heatmap]` — data-availability
  heat maps
- `[integration:fig3-hysplit-trajectories]` — HYSPLIT / trajectory
  frequency surfaces
- `[integration:fig4-pollution-rose]` — pollution + wind rose
  plots
- `[integration:fig5-obs-pred-scatter]` — observed-vs-predicted
  scatter with 1:1 line
- `[integration:fig6-feature-importance]` — RF feature importance
  bar charts
- `[integration:variables-table]` — variable dictionary /
  operational-definitions tables
- `[integration:method-code-table]` — instrument / method-code
  tables

## When to trigger

Load this sub-skill (alongside the parent) when the paper is on any
of:

- Random Forest / ML applied to air quality (H2 methods anchor).
- Wind roses, pollution roses, `openair` / `windrose` R package
  (H1, methods, Fig 4 integration).
- Refinery emissions, industrial point-source exposure, refinery
  health effects (primary RQ, tabled health extension).
- SO₂ chemistry + monitoring (H3 SO₂ side).
- O₃ photochemistry + meteorology (H3 ozone side).
- PM2.5 in coastal / Texas Gulf settings.
- Sea-breeze, coastal circulation, marine air masses (H1 + secondary
  RQ).
- HYSPLIT backward trajectories.
- FRM / FEM measurement methodology.
- Corpus Christi / Nueces County / Texas Gulf Coast environmental
  health.
- Anything the reader marks as "for the CC AQ study".

Do NOT trigger for CHM 350 or other courseworkpapers — those have
their own skills.

## Meta

- **Skill version:** v0.1.0 (2026-09-20).
- **Parent:** `scientific-paper-annotation`.
- **Maintainer:** Aidan Meyers (`aidan.meyers@tamucc.edu`).
- **Companion project skill:** `corpus-christi-aq-wind-rose-study`
  (loads full study context — this sub-skill only handles annotation).
- **License:** MIT.
