# Pipeline Architecture — GitHub repos + ETL flow

Two repositories, two roles:

| Repo | Scope | URL |
|---|---|---|
| **`south-texas-aq-pipeline`** (parent) | Full South Texas ETL — TCEQ → parquet → `aq.*` schema | <https://github.com/AidanJMeyers/south-texas-aq-pipeline> |
| **`coastal-bend-aq`** (child/docs) | Coastal Bend docs + scope docs + meeting notes + `aq_coastal_bend.*` filtered fork | <https://github.com/AidanJMeyers/coastal-bend-aq> |

The docs site is deployed from `coastal-bend-aq` via GitHub Actions →
GitHub Pages at <https://aidanjmeyers.github.io/coastal-bend-aq/>.

## ETL flow (parent pipeline)

`AirQuality South TX/pipeline/`:

```
step_00_validate_raw.py           — inventory + row-count checks on raw TCEQ .txt
step_01_build_pollutant_store.py  — legacy path (v0.3.x); superseded by 01b
step_01b_ingest_tceq_raw.py       — v0.4.0 canonical: AQS RD → 14-col CSVs by pollutant
step_01c_build_aux_stores.py      — VOCs + daily_24hr side tables
step_02_build_weather_store.py    — Open Weather / Solcast → partitioned parquet
step_02b_ingest_tceq_site_weather.py — v0.4.1: on-tower TCEQ met → partitioned parquet
step_03_compute_naaqs.py          — Design values per 40 CFR Part 50
step_04_compute_daily_aggregates.py — hourly → daily
step_05_merge_aq_weather.py       — analytical tibble (site × hour × pollutant × weather)
step_05b_build_metadata.py        — enrich site_registry with derived fields
step_06_export_analysis_ready.py  — CSV + RDS exports
step_07_load_postgres.py          — parquet + CSV → Neon aq.* tables
```

**Runbook.** `python -m pipeline.run_pipeline` executes steps 00 → 07
in order. Each step is idempotent; `if_exists: replace` on the
Postgres loader.

**Config.** `pipeline/config.yaml` — single source of truth for paths,
QC thresholds, NAAQS values, expected row counts, Postgres table list.

**Utils.** `pipeline/utils/`:

- `io.py` — path resolution + CSV/parquet helpers.
- `db.py` — SQLAlchemy engine (uses `psycopg` v3 driver).
- `logging.py` — timed step wrapper.
- `naaqs.py` — design-value math.
- `site_lookup.py` — canonical site name / aqsid mapping.
- `validation.py` — data-quality guardrails.

## Fork flow (child schema)

`aq_coastal_bend.*` is built from `aq.*` by running a filter on
`county_code IN (7, 25, 47, 131, 249, 261, 273, 297, 355, 391, 409)`
inside a `CREATE TABLE AS SELECT` per table. See
`AirQuality South TX/pipeline/sql/site_weather_hourly.sql` for the
pattern used for the newest table.

## Docs pipeline (coastal-bend-aq)

`coastal-bend-aq/`:

```
mkdocs.yml                 — theme + nav + palette + plugins
pipeline/docs/*.md         — content
pipeline/docs/assets/*     — logos, illustrations, rendered PNGs
pipeline/docs/stylesheets/ — custom CSS (extras + meeting dashboard)
pipeline/docs/javascripts/ — dashboard JS (Kanban + JSON export)
scripts/R/*.R              — R scripts that render docs figures (site map, etc.)
.github/workflows/docs.yml — build + deploy to GitHub Pages
```

**Docs deploy.** Every push to `main` triggers the workflow → build
via `mkdocs build --strict` → deploy to `gh-pages` branch. Strict
mode fails the build on any broken link — a real safety net.

## Adding a new data source (recipe)

Checklist based on the 2026-09-20 site-specific weather push:

1. **Design decision** — new table or extend existing? Different join
   key or data provenance = new table.
2. **Write an ingest step** in
   `AirQuality South TX/pipeline/step_XX_ingest_*.py`. Mirror the
   pattern of `step_02b_ingest_tceq_site_weather.py`: parse raw,
   pivot to wide, derive columns, write partitioned parquet, clean
   OneDrive artefacts.
3. **Add to `pipeline/config.yaml`:**
   - `paths.raw_*` for input source
   - `paths.parquet_*` for output dir
   - `postgres.tables` entry for the new table
4. **Write DDL** at `pipeline/sql/<table_name>.sql` — CREATE TABLE
   for `aq.*`, then `CREATE TABLE AS SELECT ... WHERE county_code IN
   (...)` for `aq_coastal_bend.*`. Include indexes + grants +
   verification queries.
5. **Load to Neon** — apply the DDL via `psql` or Neon SQL Editor,
   then run `python -m pipeline.step_07_load_postgres`, or a one-off
   `COPY FROM` script for large loads (see the 2026-09-20 scratchpad
   loader as reference).
6. **Update coastal-bend-aq docs:**
   - `pipeline/docs/02_data_sources.md` — add a new §NX describing
     the source.
   - `pipeline/docs/03_data_schemas.md` — add the table's schema.
   - `pipeline/docs/pipeline_updates.md` — new version entry.
   - Bump the version badge on `pipeline/docs/index.md`.
7. **Verify Neon** — row count matches expected; per-site coverage
   sane; joins against `pollutant_hourly` land at expected match rate.
8. **Commit both repos + push.**

## Naming + versioning conventions

- **Version format:** `vMAJOR.MINOR.PATCH` — semver-lite. MINOR
  increments on new data + new tables + significant docs
  restructures. PATCH increments on build fixes + doc corrections.
- **Meeting-notes file names:** `pipeline/docs/meeting_notes/YYYY-MM-DD.md`.
- **Briefing PPT file names:**
  `pipeline/docs/briefings/YYYY-MM-DD_INITIALS_topic_briefing.pptx`.
- **Pipeline Updates entries:** date-first heading, chronological
  sub-bullets within each version, Why + Where lines at the bottom.
  Every commit gets an entry (see `feedback_pipeline_updates_log`
  rule in Aidan's memory).

## Ownership matrix

| Layer | Owner | Notes |
|---|---|---|
| Parent `south-texas-aq-pipeline` ETL | Aidan | Rewrite only after discussion. |
| `aq_coastal_bend.*` filtered fork | Aidan | Idempotent from parent. |
| Docs content in `pipeline/docs/` | All 3 leads | PRs welcome; strict-mode build catches most issues. |
| `pipeline/docs/pollutants/*` deep-dives | Named lead per pollutant | Manasa: Ozone + CO; Aidan: PM2.5 + PM10 + NOx; Jasmine: SO₂ + VOCs. |
| `pipeline/docs/meeting_notes/*` | Aidan (auto-updated from Motion) | Can be manually edited. |
| `pipeline/docs/proposals/*` | All 3 leads + Dr. Melaram | The SharePoint doc is the live draft; scope doc mirrors. |
| Neon schema evolution | Aidan | Any DDL runs from `pipeline/sql/`. |
