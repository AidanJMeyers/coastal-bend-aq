# Team Onboarding — First Day, First Week, First Month

For anyone joining the CC AQ Wind Rose Study team.

## Before day one

- Get a TAMU-CC or Islander email.
- Have Aidan (`aidan.meyers@tamucc.edu`) add you to:
  - The **Melaram Lab OneDrive** (admin folder for templates).
  - The **`AidanJMeyers/coastal-bend-aq`** GitHub repo as a
    collaborator.
  - The **Neon project** `aged-salad-62359207` (Melaram Lab).
  - The **Motion team workspace** (for meetings + tasks).
  - The **team's Zotero collection** (shared references).
- Install Claude Code (<https://claude.com/product/claude-code>).

## Day one — read this, then check things off

**Read (in order, ~45 min total):**

1. This skill's `SKILL.md` — one-liner + product surfaces.
2. `references/study_scope.md` — research questions, hypotheses,
   variables, methods.
3. `references/decisions_log.md` — why the study is designed the way
   it is (skip to 2026-07-15 if you're pressed for time; that's the
   origin decision).
4. The live docs home: <https://aidanjmeyers.github.io/coastal-bend-aq/>.
5. The Refinery-Row scope doc:
   <https://aidanjmeyers.github.io/coastal-bend-aq/proposals/refinery_row_directional_health/>.

**Do (in order, ~30 min total):**

1. Clone the docs repo:
   ```bash
   git clone https://github.com/AidanJMeyers/coastal-bend-aq.git
   cd coastal-bend-aq
   ```
2. Set up MCPs — follow `references/mcp_setup.md` end to end. Neon
   first, Motion second.
3. Run the first-run smoke test from `mcp_setup.md` §7.
4. Skim the current [meeting-notes dashboard](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/)
   — check the "Open" column for anything with your name on it.

## Week one — situational awareness

- **Read the current SharePoint proposal draft.** Ask Aidan or
  Jasmine for the link. This is the authoritative version; the
  markdown scope doc on the pipeline is a mirror.
- **Read one pollutant deep-dive** in full (start with your assigned
  one, or with SO₂ if you're doing anything Refinery-Row).
- **Attend the next bi-weekly AQ meeting** (Wednesdays, per Motion
  Calendar; cadence confirmed at 2026-08-12).
- **Skim the most recent 3 meetings' notes.**
- **Open the Neon schema in `psql` or via MCP** and browse:
  ```sql
  \dt aq_coastal_bend.*
  SELECT * FROM aq_coastal_bend.site_registry;
  SELECT COUNT(*) FROM aq_coastal_bend.pollutant_hourly;
  ```
- **Add your name** to any relevant "owner" fields in the dashboard
  JSON (via a PR — the file is `pipeline/docs/meeting_notes/index.md`).

## Month one — becoming productive

Pick one of these paths depending on your interest + skill:

- **Analysis / modelling path.** Start with the site-weather ×
  pollutant join query from `data_inventory.md`. Build a small
  exploratory notebook. Bring it to the next meeting for feedback.
  Then: pick a pollutant (SO₂ is highest-signal) and try a
  Random-Forest baseline.
- **Data engineering path.** Read `pipeline_architecture.md` in
  full. Read one of the `step_XX_*.py` scripts end-to-end. Propose
  an improvement (usually: an ingest bug, a missing test, an
  under-documented config option).
- **Documentation path.** Read every pollutant deep-dive. Suggest
  edits — anything from tightening prose to adding a citation to
  clarifying a method-code note. All docs are Markdown + git —
  PRs land the same day.
- **Meteorology / atmospheric physics path.** Read
  `references/study_scope.md` §Hypotheses + §Prior work. Read the
  proposal's HYSPLIT plan. Ping Jasmine about her NWS collaboration
  and see where you can plug in.

## Communication norms

- **Standing meeting:** bi-weekly, Wednesday evenings CT. Motion
  Calendar has the invite; ping Aidan if it's missing.
- **Async default:** GitHub issues + PRs for anything the whole team
  should see. Motion tasks for individual to-dos.
- **Text/email for urgent / same-day items.** Don't let a meeting
  action item die in a Motion queue — ping the owner directly if
  it's blocking you.
- **AI-in-the-room policy:** every meeting is recorded via Motion
  AI Notetaker. Minutes land automatically in the pipeline within
  ~24 h after the meeting. If you spot an error in the notes, edit
  the markdown file (`pipeline/docs/meeting_notes/YYYY-MM-DD.md`)
  and PR it.

## What you don't need to know

- **How the parent `south-texas-aq-pipeline` works internally.**
  Only Aidan touches it. Everything you need lands as tables in
  `aq_coastal_bend.*`.
- **BREATHE-CC study details.** That's a sibling project (Melaram
  Lab pediatric respiratory cohort). We interact with it only for
  future health-outcome work, which is currently tabled — see
  `references/decisions_log.md` (2026-07-29 entry).
- **The `!Archive_v0_3_7/` folder in the parent pipeline.**
  Historical snapshot of the EPA-blended data model. Not touched
  since 2026-05.

## Getting stuck

- **MCP not connecting:** re-read `mcp_setup.md` §4 (Windows
  gotchas). Fall back to `psql` per §6 if Neon MCP won't cooperate.
- **Neon MCP hangs (Windows):** you're hitting the same bug that
  bit the team in September. Switch to the remote HTTP endpoint per
  `mcp_setup.md` §1.
- **Docs build breaks after your PR:** strict-mode caught a broken
  link. Look at the GitHub Actions log — it names the exact page +
  link.
- **You're not sure what a variable in the proposal means:** check
  `references/study_scope.md` §Variables first, then the actual
  proposal draft in SharePoint, then ask on the team channel.

## Escalation

- **Data questions →** Aidan.
- **Methodology questions →** Jasmine (wind/meteorology) or Manasa
  (chemistry).
- **Publication / grant questions →** Dr. Melaram.
- **Nothing works, everything is on fire →** ping Aidan directly.
