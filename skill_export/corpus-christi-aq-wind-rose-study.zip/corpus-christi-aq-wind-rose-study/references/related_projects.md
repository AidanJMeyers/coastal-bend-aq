# Related Projects + Cross-Study Context

## Parent — `south-texas-aq-pipeline` (Melaram Lab)

**Repo:** <https://github.com/AidanJMeyers/south-texas-aq-pipeline>
**Docs:** <https://aidanjmeyers.github.io/south-texas-aq-pipeline/>

The broader 13-county South Texas ETL pipeline this study forked from.
Full South Texas coverage — 42 sites, ~10M rows across the `aq.*`
schema. Coastal Bend is a **county-filtered subset** built by running
`county_code IN (7, 25, 47, 131, 249, 261, 273, 297, 355, 391, 409)`
against the parent tables.

**Why the fork:**
1. Focus — Dr. Melaram wants a publishable Coastal Bend analysis
   as the first output.
2. Method rigor — with 8 sites we can genuinely audit every method
   code change (vs 42 sites where that becomes a full-time job).
3. Publishable scope — the Coastal Bend has a coherent industrial
   footprint (Refinery Row) that gives us a clean geographic frame.
4. Extensibility — the pipeline still works at the full 42-site scale.

**Prior publication (parent scope):** Sanchez-Warren et al. (2026)
Corpus Christi time-series paper covering 2019–2023 across four
Corpus Christi monitors. That paper documents the baseline temporal
structure (spring ozone peaks, summer PM2.5 maxima, temperature +
wind speed + precipitation associations). **This new study extends
by adding direction** — the missing dimension in the prior work.

## Sibling — BREATHE-CC pediatric respiratory cohort (Melaram Lab)

**Repo:** <https://github.com/AidanJMeyers/breathe-cc-documentation>

Ongoing longitudinal cohort study of pediatric respiratory outcomes
in the Coastal Bend. Uses REDCap for enrolment + follow-up
questionnaires; TAMU-secure-drive workflow for the quarterly
analytic file.

**Relationship to this study:**

- **Currently:** no data flow. BREATHE-CC is in enrolment phase and
  cannot yet support health-outcome analysis (< 150 participants).
- **Future:** once BREATHE-CC hits 150 participants (~2027 earliest),
  the tabled health-outcome extension of this study could layer
  onto the base model. The K-fold split in the base model
  (fold 3 held out) is specifically designed so a future
  health-outcome stack can be trained on unseen predictions without
  contaminating the base evaluation.
- **Coastal Bend AQ data is exposed to BREATHE-CC students via the
  Neon Data API.** Same `aq_coastal_bend` schema, no separate
  copy. Once the quarterly analytic file architecture is running
  (agreed at 2026-07-08 sync), BREATHE-CC students without direct
  REDCap access will consume de-identified rolling releases from
  the TAMU secure drive.

Dr. Melaram (2026-07-29): *"Definitely not happening [for the
health layer]. Two more years — at least a year and a half."*
See `decisions_log.md` (2026-07-29 entry) for the tabling
rationale.

## Potential collaboration — Dr. Deb Niyogi (UT Austin)

**Lab:** Extreme Weather and Urban Sustainability Lab, UT Austin
Jackson School.

**How the signal surfaced:** Jasmine interviewed at UT Austin
2026-08-12 and mentioned this project. Dr. Niyogi *"nearly jumped
out of his seat"* — his group is actively working on **thunderstorms
× aerosol trajectories × asthma**. Directly-relevant overlap:

- **His group has the health data we're missing.** If a
  collaboration formalises, this substantially compresses the
  timeline by trading the "wait for BREATHE-CC" constraint for a
  joint-project structure.
- **Joint call scheduled 2026-08-14 at noon CT** with Jasmine +
  Dr. Melaram.

**Status as of 2026-09-20:** call held; follow-up in the
2026-09-20 meeting notes if anything actionable came out. If not
yet formalised, Dr. Niyogi remains a warm lead — not on the
critical path for the base model.

## Analog / adjacent studies in the literature

Not collaborators, but worth reading if you're new to the design:

- **Houston sea-breeze × PM2.5 recirculation** (Bralić / Kotsakis
  et al., 2024) — nearest Gulf-coast analog. Uses k-means on wind
  direction to identify recirculation events; documents PM2.5
  response. Different geography, similar physics.
- **Cape Town refinery + childhood asthma** (White et al., 2009) —
  the only prior study using wind-vector-weighted refinery
  exposure. Now nearly 20 years old; used questionnaires, single
  cross-section, no ML. This study is a direct methodological
  extension.
- **Montreal refinery SO₂ + asthma** (Smargiassi et al., 2009) —
  the canonical wind-direction-weighted refinery health paper.
  Blueprint for the tabled health-outcome extension.

## Other Melaram Lab projects (context only)

- **BREATHE-CC** — as above.
- **Environmental toxicology work** with Dr. Johnson (College
  Station) — potential overlap for future toxicology-informed
  discussion sections.
- **Community 4 Change (C4C)** — advocacy / policy work Aidan
  participates in; possible policy-brief venue for the eventual
  Refinery-Row findings.
