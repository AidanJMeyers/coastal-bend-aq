# Decisions Log

Chronological log of every consequential decision made for the study.
Load this to catch up on *why* the current design exists.

## 2026-06-24 — Scope pivot to Coastal Bend

- **Pivoted** from the broader 13-county South Texas region to the
  11-county Coastal Bend, per Dr. Melaram's direction.
- **Rationale:** focused first manuscript, cleaner geography, tractable
  method-code audit at 8 monitor sites vs 42.
- **Impact:** created the `aq_coastal_bend` Neon schema as a
  county-filtered fork of the parent `aq` schema. Full South Texas
  pipeline preserved intact.
- Team assignments locked: Ozone + CO → Manasa; PM2.5 + PM10 + NOx →
  Aidan; SO₂ + VOCs → Jasmine.

## 2026-07-08 — Team PPT briefings + method-code rigor

- Each lead presented a deep-dive on their assigned pollutant(s):
  chemistry, FRM/FEM instrumentation, method codes, NAAQS, weather
  drivers, literature.
- **Decision: drop CO** from the first manuscript scope — no CO
  monitors anywhere in the Coastal Bend region.
- **Decision: redo raw ingest** to preserve per-row method codes
  (satisfies future cross-year comparability).
- **Decision: consider a standalone perspective paper** on TCEQ vs
  EPA methodology + method-code semantics + measurement-unit
  divergence (Dr. Melaram's suggestion).
- Dr. Melaram: *"y'all clarified the FEM and FRM very well… it hit
  the science very well."*

## 2026-07-15 — Pollution Rose → Refinery-Row directional health study pivot (origin)

- **Jasmine — foundational insight.** Introduced the **pollution-rose**
  framing (wind-rose analytics extended to show where each pollutant is
  *heading* at what severity). This is the anchor idea the rest of the
  design builds on.
- **Manasa — refinery-centering.** Proposed centering the analysis on
  the Port of Corpus Christi refinery corridor and pointed the team at
  the R `openair` package.
- **Aidan — ML + health-outcome coupling** (later tabled — see below).
- **Dr. Melaram — grant + significance framing.**
- **Decision: pursue this as the core project direction.**
- **Decision: Warden + Jin joint session** to consult on ML methods.
  Schej poll to go out.
- **Decision: potential grant resubmission** (climate-change seed
  grant that was denied on feasibility).

## 2026-07-22 — Literature-scan check-in (Aidan + Dr. Melaram absent)

- Jasmine surfaced Ecuador 2017 PM2.5 wind-rose paper as
  directionally-adjacent prior work.
- Confirmed: the specific study design (refinery-centered directional
  pollution + health outcome + ML) is niche and mostly novel.

## 2026-07-29 — K-fold stacked model + Random Forest single-model start; health-outcome extension TABLED

- **Structural blocker identified.** BREATHE-CC health-outcome target
  data is 1.5–2 years away from being usable (150-participant
  threshold before cohort profile paper is even eligible).
- **Decision: table the health-outcome extension** entirely from the
  current-project scope. Health becomes future work.
- **Jasmine's K-fold stacked model design.** Base model (buildable
  now) trains on folds 1+2 and reserves fold 3 as unseen test set.
  Future health-outcome stack can be layered onto the base model
  without contaminating the base evaluation.
- **Decision: Random Forest single-model start.** No premature
  model shopping. Escalate to XGBoost / neural nets only if
  performance is unacceptable.
- **Decision: pollutants = SO₂ + O₃ (10-yr coverage); PM2.5
  optional (7-yr).**
- **Decision: deliverable = 15-slide proposal** by the 2026-08-05
  meeting.
- **Manasa's DSHS find** — Texas DSHS publishes ED-visit data via
  public-use request; a viable alternative target dataset for a
  future health extension.

## 2026-08-12 — Proposal-template working session + CAMS site-label catch + Niyogi signal

- **Decision: bi-weekly meeting cadence** for fall (was weekly).
- **Research question refined** to grad-level explicitness: SO₂ +
  Ozone, 2015-2025, Random Forest, 7 meteorological covariates.
- **Jasmine's H1 hypothesis crystallised** — direction prediction
  more accurate than concentration, because Corpus Christi wind is
  remarkably constant across seasons.
- **Wind-direction encoding — 3 forms in parallel:** continuous
  degrees, u/v decomposition, 16 categorical sectors.
- **Wind gusts + boundary layer height EXCLUDED** — too sparse /
  no reliable data source. Documented as limitations.
- **Method code = supplementary table, not analytic variable.**
- **Sensitivity threshold for daily completeness** = < 18 valid hours
  flagged; treat as a knob, not fixed.
- **Imputation transparency requirement** — final paper must report
  percentage imputed overall and per pollutant.
- **Site-label "mislabel" flagged** (later reconciled at 2026-08-26
  — see below).
- **UT Austin — Dr. Deb Niyogi** signal. His Extreme Weather and
  Urban Sustainability Lab has active work on thunderstorms ×
  aerosol × asthma AND holds the health data we're missing.
  Joint call scheduled 2026-08-14.
- **Decision: Zotero for interim citation management; EndNote at
  publication.**

## 2026-08-26 — SharePoint proposal link + TCEQ↔AQS reference + CAMS 32/34 mislabel RECONCILED

- **Discovery:** the 2026-08-12 "mislabel" concern was actually a
  **CAMS ID (TCEQ) vs `site_number` (AQS/pipeline) confusion** —
  two different identifier systems for the same site. Neon labels
  were correct all along:
  - AQS 32 = "Corpus Christi Huisache_0032" (correct)
  - AQS 34 = "Corpus Christi Dona Park_0034" (correct)
- **Decision: Manasa's SQL rename NOT NEEDED.** Reference doc
  [13_tceq_cams_aqs_reference.md](https://aidanjmeyers.github.io/coastal-bend-aq/13_tceq_cams_aqs_reference/)
  created as the authoritative CAMS ↔ AQS mapping.
- **Decision: scope-doc restructured** — health-outcome extension
  moved to tabled bottom section. Base AQ model (Random Forest ×
  pollution rose on SO₂ + Ozone) is now the manuscript deliverable.
  Timeline compressed from 1–1.5 yr to 6–9 months.
- **SharePoint proposal draft link surfaced across the pipeline**
  (site home card + scope doc callout + proposals index).

## 2026-09-20 (afternoon) — Site-specific TCEQ meteorology + Neon reconfig

- **Decision: add new Neon table `site_weather_hourly`** — on-tower
  TCEQ met from 4 monitored sites (25, 26, 32, 34). Distinct from
  regional `weather_hourly` (Open Weather feed).
- **Rationale:** the sensor is co-located with the pollutant
  analyzer (< 100 m offset); regional wind at ~10 km resolution
  smears over the sea-breeze × industrial-plume dynamics the model
  needs.
- **Result:** 382,654 rows loaded via `COPY FROM` in 49 seconds.
  Coverage: 99% temp / wind speed / wind gust, 88% scalar wind
  direction, 33% resultant wind direction.
- **Decision: Neon MCP reconfigured to remote HTTP endpoint**
  (`https://mcp.neon.tech/mcp`) after the local `npx`-spawned
  server proved unusable on Windows (silent stdio deadlock).
  Aidan signs in via OAuth in `/mcp` once and MCP works from then on.

## 2026-09-20 (evening) — Proposal review + Refinery-Row proximity variable

- **Attendees:** Aidan, Jasmine, Manasa (Dr. Melaram absent).
- **Decision: add a Refinery-Row proximity variable** and use wind
  direction *relative to* Refinery Row as a derived predictor.
  Formalises the Refinery-Row bearing construct.
- **Decision: sensitivity analysis over distance effects** — vary
  cone width + distance weighting to test whether directional signal
  degrades linearly with distance from the corridor.
- **Decision: joint session with Dr. Melaram + Dr. Jin + Dr. Warden**
  targeted for the week of 2026-10-04. Jasmine sends Schej poll
  Monday 2026-09-22.
- **Decision: interim touch-base 2026-10-04** for a quick task-
  assignment sync (Aidan available after 2026-10-01).
- **Decision: timeline is a living document.** Aidan adds a note in
  the proposal doc.
- **Decision: PM10 dropped from the site map figure** — cleaner
  visual (Manasa).
- **Decision: create this skill** for team onboarding + shared
  knowledge base (packaged for export).

## Standing / unresolved decisions

- **VOC retro-pull for pre-2025 24-hr VOCs** — carried from 2026-06-24.
- **EPA-network Cameron / Hidalgo boundary-site inclusion** — carried
  from 2026-06-24.
- **Delaney (TCEQ) outreach** for method-code confirmations —
  Jasmine has the relationship.
- **Climate-change seed grant resubmission** — Dr. Melaram exploring
  after the initial NIHS meeting.
- **National Seashore CAMS 314 inclusion** — optional site
  documented in the CAMS-AQS reference; team hasn't decided.
- **Historical CC Holly CAMS 660 inclusion** — optional pre-2018
  data for one refinery-adjacent site; team hasn't decided.
