# Publication + Policy Plan

## Target journals (base model — current scope)

Ranked by fit + realistic ambition:

| Journal | Impact factor (approx) | Fit |
|---|---:|---|
| **Environmental Modelling & Software** | ~5 | Strong methodological fit (openair, ML, exposure attribution). |
| **Atmospheric Environment** | ~5 | Strong for the sea-breeze + pollution-rose analysis. |
| **Environmental Research** | ~8 | Reach; publishable if the RF results are clean + the Refinery-Row angle carries novelty. |
| **Journal of Exposure Science & Environmental Epidemiology** | ~6 | Precedent for Texas-specific PM2.5 ML (Chudnovsky et al. 2024). |

If the tabled health-outcome extension eventually gets un-tabled and
run:

| Journal | Impact factor (approx) | Fit |
|---|---:|---|
| **Environmental Health Perspectives** | ~10 | The gold standard for AQ + health. |
| **Environment International** | ~12 | Broad reach; strong for the point-source × exposure story. |

## Policy angle

The study's direct outputs speak to:

- **Corpus Christi + Nueces County zoning + industrial permitting.**
  Directional exposure characterisation at hourly resolution is
  actionable for community-siting decisions in a way that annual
  design values are not.
- **TCEQ monitoring strategy.** The pollution rose can indicate where
  additional monitors would add the most information (i.e., which
  downwind residential zones are currently under-monitored).
- **EPA facility-permitting reviews.** Especially for cumulative-
  impact assessments in the Refinery Row corridor.

## Grant reuse

- **Climate-change seed grant** — previously submitted by Dr. Melaram,
  denied on feasibility, high on novelty + significance. This project
  directly addresses that critique (methodological depth, specific
  dataset, clear exposure-outcome link, more hands on deck).
  Resubmission being explored.
- **R25 track** — Dr. Melaram exploring after NIHS meeting.

## Supporting outputs (side papers Dr. Melaram floated)

- **Perspective / commentary paper on TCEQ vs EPA methodology +
  method-code semantics.** A short, high-yield piece that establishes
  exposure-attribution rigor. Would draft from the pollutant
  deep-dives + the TCEQ ↔ AQS reference doc. Dr. Melaram's
  2026-07-08 suggestion.

## Reference list (working — full drafts in Zotero)

The following are already anchored in the proposal draft's Study
Rationale section. Full APA-7 formatting happens at manuscript stage.

- Liu, Y., et al. (2019). Ambient particulate matter and mortality:
  652-city analysis.
- Lim, C. C., et al. (2019). Long-term ozone exposure + cause-specific
  mortality in the U.S.
- Bryan, D., & Landrigan, P. J. (2023). Statewide geospatial
  assessment of Texas PM2.5 attributable mortality.
- Goodman, P., et al. (2017). Short-term ozone + asthma hospital
  admissions in Texas cities.
- Smargiassi, A., et al. (2009). Risk of asthmatic episodes in
  children exposed to SO₂ from a refinery point source, Montreal.
- Stasio, A., et al. (2023). Refinery Row emissions inventory
  (Corpus Christi).
- Camalier, L., et al. (2007). Meteorological + urban ozone.
- Zhou, Y., et al. (2023). Texas Gulf coast sea breeze sulfate
  advection.
- Sanchez-Warren, A., et al. (2026). Melaram Lab prior Corpus Christi
  time-series paper (2019-2023).
- White, N. C., et al. (2009). Cape Town refinery wind-derived
  exposure + asthma.
- Breiman, L. (2001). Random Forest.
- Pernak, R., et al. (2019). RF for Texas air-quality forecasting.
- Carslaw, D. C., & Ropkins, K. (2012). openair R package.
- Chudnovsky, A. A., et al. (2024). High-resolution PM2.5 ML
  prediction in Texas.
- Bralić, D. / Kotsakis, A. et al. (2024). Houston sea-breeze × PM2.5
  recirculation.

## What we're not publishing (yet)

- **Health-outcome layer** — see `decisions_log.md` (2026-07-29
  tabling decision) and the tabled section at the bottom of the
  Refinery-Row scope doc.
- **Spatial interpolation to unmonitored Coastal Bend counties** —
  9 of 11 counties have no monitors; interpolation from 8 anchors is
  a hard problem that the team has flagged as a separate future
  paper.
