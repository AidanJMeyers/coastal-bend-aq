# Data Inventory — Neon Schema Tour

The database is the deliverable. Everything the team consumes lives in
Neon Postgres — project `aged-salad-62359207`, US-East-1.

## The two schemas

| Schema | Scope | Row count | Use for |
|---|---|---:|---|
| `aq` | Full South Texas (13 counties, 42 sites) | ~10M+ | Parent pipeline; comparison / cross-region work. |
| `aq_coastal_bend` | County-filtered fork (11 Coastal Bend counties, 8 sites) | ~1.7M | **The study's primary schema.** |

The forks are populated by county-code filter on the AQS `site_number`
in each parent table. Same schema shape, subset of rows.

## Tables (10 in each schema)

Live snapshot from 2026-09-20:

| Table | Rows (`aq_coastal_bend`) | Grain | Notes |
|---|---:|---|---|
| `site_registry` | 8 | one row per site | Coordinates, county, pollutants tracked, active/disabled. |
| `parameter_reference` | 57 | one row per AQS code | HAP flags, units, pollutant_group routing. |
| `naaqs_design_values` | 129 | site × year × pollutant | Computed per 40 CFR Part 50. |
| `pollutant_hourly` | 768,243 | site × hour × pollutant | Criteria pollutants (no VOCs). |
| `pollutant_daily` | 31,015 | site × date × pollutant | Derived from hourly. |
| `pollutant_daily_24hr` | 0 | site × date × pollutant | Empty in Coastal Bend (site 0060 is Bexar). |
| `pollutant_monthly` | 1,035 | site × month × pollutant | Derived. |
| `vocs_1hr` | 336,922 | site × hour × VOC species | CC Palm, 2025, 46 species. |
| `vocs_24hr` | 7,152 | site × day × VOC species | Hillcrest, Dona Park, Huisache, 2025, 48 species. |
| `weather_hourly` | 197,124 | station × hour | Regional Open Weather + Solcast. |
| `site_weather_hourly` | 382,654 | monitor × hour | **v0.4.1 addition** — on-tower TCEQ met, 4 Nueces sites, 2015-2025. |

**Total: ~1.7M rows, ~310 MB.**

## Site inventory (Coastal Bend, 8 sites)

Live from `aq_coastal_bend.site_registry` on 2026-08-26:

| AQS ID | site_number | Site name | County | Hourly pollutants | 24-hr / VOC | On-monitor met? |
|---|---:|---|---|---|---|:---:|
| 482730314 | 314 | Kingsville_0314 | Kleberg | PM2.5 | — | ❌ |
| 483550025 | 25 | Corpus Christi West_0025 | Nueces | Ozone, SO₂ | — | ✅ |
| 483550026 | 26 | Corpus Christi Tuloso_0026 | Nueces | Ozone, SO₂ | — | ✅ |
| 483550029 | 29 | Corpus Christi Hillcrest_0029 | Nueces | — | 24-hr VOCs | ❌ |
| 483550032 | 32 | Corpus Christi Huisache_0032 | Nueces | PM2.5, SO₂ | 24-hr VOCs | ✅ |
| 483550034 | 34 | Corpus Christi Dona Park_0034 | Nueces | PM10, PM2.5, SO₂ | 24-hr VOCs | ✅ |
| 483550083 | 83 | Corpus Christi Palm_0083 | Nueces | — | 1-hr VOCs | ❌ |
| 483551024 | 1024 | Williams Park | Nueces | — | — | (disabled) |

## CAMS ID (TCEQ) ≠ site_number (AQS)

**Two identifier systems for the same site.** Always confirm which one
the source is using:

| System | Owner | Example |
|---|---|---|
| **TCEQ CAMS ID** | TCEQ TAMIS portal | CAMS 98, CAMS 199, CAMS 660 |
| **EPA AQS `site_number`** | AQS / our pipeline | 25 (CC West), 32 (Huisache), 34 (Dona Park) |
| **Full AQS ID** | EPA | `483550032` = TX (48) + Nueces (355) + site 32 |

**One AQS site_number can span multiple TCEQ CAMS IDs** at the same
physical location (one CAMS per analyzer). Example: AQS 32 (Huisache)
covers TCEQ CAMS 98 + 149 + 155. Full mapping table lives at
<https://aidanjmeyers.github.io/coastal-bend-aq/13_tceq_cams_aqs_reference/>.

## Sample queries

**Design values for 2024, sorted by exceedance:**

```sql
SELECT site_name, metric, ROUND(value::numeric, 4) AS value, exceeds
FROM   aq_coastal_bend.naaqs_design_values
WHERE  year = 2024
ORDER  BY exceeds DESC, value DESC;
```

**Site-weather × pollutant join for the modelling tibble:**

```sql
SELECT ph.aqsid, ph.datetime_local, ph.pollutant_group, ph.sample_measurement,
       swh.temp_c,
       swh.wind_speed_resultant_ms,
       swh.wind_direction_scalar_deg,
       swh.wind_u_scalar_ms, swh.wind_v_scalar_ms,
       swh.wind_gust_ms
FROM   aq_coastal_bend.pollutant_hourly ph
JOIN   aq_coastal_bend.site_weather_hourly swh
       ON ph.aqsid::bigint      = swh.aqsid
      AND ph.date_local::date   = swh.date_local
      AND ph.hour                = swh.hour_local
WHERE  ph.aqsid::bigint IN (483550025, 483550026, 483550032, 483550034)
  AND  ph.pollutant_group IN ('Ozone', 'SO2');
```

**Pollutant coverage table per site:**

```sql
SELECT aqsid, pollutant_group,
       COUNT(*) AS n_obs,
       MIN(date_local) AS first_obs,
       MAX(date_local) AS last_obs
FROM   aq_coastal_bend.pollutant_hourly
GROUP  BY aqsid, pollutant_group
ORDER  BY aqsid, pollutant_group;
```

## Site-weather variable dictionary

`aq_coastal_bend.site_weather_hourly` columns (v0.4.1):

| Column | Type | Unit | Notes |
|---|---|---|---|
| `aqsid` | bigint | — | Full 9-digit AQS ID (site key) |
| `date_local` | date | — | Local date |
| `hour_local` | smallint | 0-23 | Local hour |
| `datetime_local` | timestamp | — | Concatenation of the above |
| `year`, `month` | smallint | — | Partition helpers |
| `wind_speed_resultant_ms` | double | m/s | AQS 61101 |
| `wind_direction_resultant_deg` | double | ° compass | AQS 61102; ~33% coverage — prefer scalar |
| `wind_speed_scalar_ms` | double | m/s | AQS 61103 |
| `wind_direction_scalar_deg` | double | ° compass | AQS 61104; ~88% coverage |
| `wind_gust_ms` | double | m/s | AQS 61105 |
| `temp_f` | double | °F | AQS 62101 |
| `temp_c` | double | °C | Derived: (temp_f − 32) × 5/9 |
| `wind_u_ms`, `wind_v_ms` | double | m/s | Zonal + meridional from resultant pair |
| `wind_u_scalar_ms`, `wind_v_scalar_ms` | double | m/s | Same from scalar pair (higher coverage) |
| `poc_*` | smallint | — | Which POC used per parameter (audit trail) |
| `method_*` | text | — | AQS method code per parameter |

**Wind vector convention:** meteorological — wind direction is the
direction wind is *coming from*, so `u = −ws · sin(θ)` and
`v = −ws · cos(θ)` (negative sign flips to transport-vector).

## Access

- **Neon SQL/psql:** `AQ_POSTGRES_URL` env var → schema `aq_coastal_bend`.
- **Neon Data API (REST):** available on the anonymous +
  authenticated roles.
- **Neon MCP:** connected via `/mcp` in Claude Code — see
  `mcp_setup.md` for the reconfig required to make it work on
  Windows.

Full API examples in [09 Python / R examples](https://aidanjmeyers.github.io/coastal-bend-aq/09_usage_python_r/)
on the docs site.
