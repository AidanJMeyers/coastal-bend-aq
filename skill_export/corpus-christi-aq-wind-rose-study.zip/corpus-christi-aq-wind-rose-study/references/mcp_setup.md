# MCP Setup for Teammates

Getting Claude Code (or Claude Desktop) wired up to talk to the study's
data sources. Order matters — do Neon first, Motion second, Gmail third.

## Prerequisites

- **Claude Code CLI** or **Claude Desktop** installed
  (<https://claude.com/product/claude-code>).
- **Node.js 18+** on your machine (only needed for some legacy local
  MCP servers).
- **Neon account** with access to the Melaram Lab project
  `aged-salad-62359207` — ask Aidan to add your email.
- **Motion account** — TAMU-CC email works with the lab workspace.

## 1. Neon MCP (required for anyone querying the database)

**Do not use the local `npx @neondatabase/mcp-server-neon` approach on
Windows** — it hangs silently on the stdio handshake in v0.6.5+.
Use the hosted remote endpoint instead. It's faster, doesn't need a
local API token, and just works.

**Config location.** For a project-scoped setup, create
`.mcp.json` at the root of the repo you're working in
(`~/OneDrive/Desktop/coastal-bend-aq/.mcp.json` or similar) with:

```json
{
  "mcpServers": {
    "neon": {
      "type": "http",
      "url": "https://mcp.neon.tech/mcp"
    }
  }
}
```

**Auth:**

1. Start Claude Code in that directory.
2. Type `/mcp`. You'll see `neon` in the list with status
   `needs_auth`.
3. Click the row → a browser tab opens → sign in via GitHub or
   Google (whichever your Neon account uses).
4. Approve the OAuth grant for the Melaram Lab organisation.
5. Return to Claude Code — the status flips to `connected` and the
   `mcp__neon__*` tools become available.

**Verify:** ask Claude "list my Neon projects" — you should see
`south-texas-aq` in the response.

**Global setup (optional).** If you want Neon MCP available in every
Claude Code session regardless of directory, add the same block to
`~/.claude/mcp.json`.

## 2. Motion Notes + Motion Calendar MCPs (recommended)

Motion's AI Notetaker records the team's meetings and produces
summaries + action items. The Motion MCPs let Claude read them
directly.

**These come via the Anthropic MCP plugin store, not as a config
file.** Steps:

1. In Claude Code, type `/mcp` → `Add MCP Server`.
2. Search for "Motion Notes" → install.
3. Search for "Motion Calendar" → install.
4. OAuth-flow both — sign in with your `usemotion.com` account.
5. Confirm status = `connected` for both in `/mcp`.

Verify: ask Claude "list my recent Motion meetings" — you should
see today's + this week's meetings.

**Available Motion tools (once connected):**

- `list_meeting_notes` — recent meetings.
- `search_meeting_notes` — keyword search.
- `get_meeting_note` — full summary + action items for one meeting.
- `list_action_items` — cross-meeting action-item list.

## 3. Gmail MCP (optional but useful)

Lets Claude read your inbox (e.g. to auto-ingest Motion emails or
Schej poll responses).

1. In Claude Code, `/mcp` → `Add MCP Server`.
2. Search for "Gmail" → install → sign in.
3. Grant read access. Do NOT grant send access unless you explicitly
   want Claude to send emails.

## 4. Windows-specific gotchas

- **OneDrive polluting `.git/refs`** — OneDrive sometimes drops
  `desktop.ini` files into the git refs directory, which breaks
  `git log`, `git fetch`, etc. Fix: `find .git/refs -name
  "desktop.ini" -delete`. Longer-term, exclude your project
  folder(s) from OneDrive sync.
- **Local Neon MCP hang** — covered above. Use the remote endpoint.
- **npx cold-starts** — even for other MCPs, `npx -y package start`
  can take 45+ seconds on first invocation because it fetches the
  package fresh. If a local MCP hangs, try installing globally
  (`npm install -g <package>`) and pointing `.mcp.json` at the
  absolute path to the binary in
  `C:/Users/<you>/AppData/Roaming/npm/`.

## 5. Auth cheat sheet

| Credential | Where stored | Rotation cadence |
|---|---|---|
| Neon OAuth token | Claude Code's credential store; not in any file | Auto-refresh via OAuth |
| `AQ_POSTGRES_URL` env var | Your shell profile (`~/.bashrc`, `$PROFILE`, etc.) | Rotate if it appears in any output/log; expected annual |
| Motion OAuth | Claude Code's credential store | Auto-refresh via OAuth |
| GitHub CLI (`gh auth login`) | System keychain | Auto-refresh via GitHub |

**Never** put a plaintext API token in a file that gets committed to
git. `.mcp.json` should either use OAuth (as with the remote Neon
endpoint) or reference an environment variable. If a token is
accidentally committed or shows up in chat/tool output, rotate it
immediately.

## 6. Neon SQL fallback (if MCP is offline)

Direct connection using `psycopg` (v3):

```python
import os
import psycopg
with psycopg.connect(os.environ["AQ_POSTGRES_URL"]) as conn:
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM aq_coastal_bend.site_weather_hourly")
        print(cur.fetchone())
```

Or via `psql` at the command line if you have it installed:

```bash
psql "$AQ_POSTGRES_URL" -c "SELECT COUNT(*) FROM aq_coastal_bend.site_weather_hourly;"
```

## 7. First-run smoke test

Once everything is connected, ask Claude:

> *"List the sites in the Coastal Bend Neon schema and tell me which
> ones have on-monitor meteorology."*

You should get an 8-row table with 4 sites marked as having on-monitor
met (aqsids 25, 26, 32, 34). If you get an error, work backward from
which MCP failed and re-check the auth flow above.
