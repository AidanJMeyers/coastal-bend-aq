# Study Scope — Refinery-Row Directional Air-Quality Modelling

**Working title.** *Directional pollutant-transport modelling downwind
of the Port of Corpus Christi refinery corridor: a Random-Forest ×
pollution-rose analysis of SO₂, Ozone, and PM2.5 over 2015–2025.*

## Research questions

**Primary.**
How accurately can a Random Forest (RF) model predict the transport
direction and concentration of criteria air pollutants (SO₂, O₃, and
where coverage permits PM2.5) from routine meteorological observations
in the Corpus Christi Refinery-Row region, 2015–2025?

**Secondary.**
Do the resulting directional patterns vary systematically by season and
by year, and is that variation consistent with environmental control
(e.g., sea-breeze / frontal-reversal) of transport from Refinery Row?

**Exploratory.**
Can the same model and variables support a categorical AQI-band
classifier suitable for practical, public-facing early-warning output?

**Future (tabled).**
Can predicted pollutant transport patterns improve the prediction of
respiratory health outcomes when integrated with the BREATHE-CC cohort?
(Deferred — see `decisions_log.md` for the 2026-07-29 tabling decision.)

## Hypotheses (Jasmine's H1–H4)

**H1 — Direction beats concentration in RF performance.**
The Random Forest model will predict pollutant transport direction more
accurately than pollutant concentration (higher R² on directional
target). Corpus Christi wind direction is strongly constrained by the
persistent south / south-southeasterly Gulf sea breeze; hourly
concentration additionally reflects unobserved emission-source dynamics
and atypical meteorological or anthropogenic events.

**H2 — Top RF features will be season, wind speed, temperature.**
Season captures the shifts in prevailing wind patterns (summer sea-breeze
vs winter reverse flows). Wind speed carries the transport magnitude.
Temperature drives photochemical reactivity, especially for O₃.

**H3 — SO₂ is transport-controlled; O₃ is photochemistry-controlled.**
Wind-derived predictors (wind vectors, wind speed, Refinery-Row bearing)
will dominate SO₂ models; photochemical predictors (solar irradiance,
temperature) will dominate O₃ models. Consistent with SO₂ as a primary
transport-limited pollutant and O₃ as a secondary photochemically
controlled pollutant.

**H4 — Exploratory: AQI-band model behaves defensibly on high-risk days.**
Evaluate the AQI classifier's error rate at each band, especially the
high-concentration bands that pose the greatest public-health risk.

## Sites in scope (Nueces County, 4 active monitors around Refinery Row)

| Site | AQS ID | Pollutants (record period) | Rows |
|---|---|---|---:|
| Corpus Christi West | 48-355-0025 | O₃, SO₂ (2015-2025) | 184,842 |
| Corpus Christi Tuloso | 48-355-0026 | O₃, SO₂ (2015-2025) | 173,063 |
| Corpus Christi Huisache | 48-355-0032 | SO₂ (2015-2025); PM2.5 (2018-2025) | 208,787 |
| Corpus Christi Dona Park | 48-355-0034 | PM2.5 (2015-2025); SO₂ (2015-2017) | 104,428 |

**Total analytic dataset:** 671,120 hourly pollutant observations
(Jan 2015 → Dec 2025) with concurrent hourly meteorology.

**Excluded from primary scope:**

- **CC Holly (CAMS 660):** deactivated 2018-12-03.
- **CC Hillcrest (48-355-0029) + CC Palm (48-355-0083):** VOC-only, no
  criteria-pollutant time series in the modelling window.
- **Kingsville (48-273-0314, Kleberg):** too geographically remote from
  Refinery Row for the directionality logic.
- Other 9 Coastal Bend counties: no TCEQ monitoring at all.

See `data_inventory.md` for the full site inventory + CAMS/AQS
mapping table.

## Variables

**Targets (pollutants):** SO₂ (hourly, ppb), O₃ (hourly, ppb → ppm),
PM2.5 (hourly, µg/m³). See the pollutant deep-dive pages on the docs
site for method-code timelines.

**Meteorological predictors:**

- Wind speed (resultant + scalar), m/s.
- Wind direction (resultant + scalar), degrees + u/v components +
  16-sector categorical.
- **Refinery-Row bearing** — angular offset (0–180°) between the
  observed wind vector and the great-circle bearing from Refinery-Row
  centroid to each monitor site. Derived per site × hour.
- Wind gust, m/s.
- Ambient temperature (°F on TCEQ side; standardised to °C).
- Heat index.
- Relative humidity, %.
- Atmospheric pressure, hPa.
- Precipitation (hourly rainfall, mm + binary is_raining).
- Cloud coverage.
- Solar radiation (from OpenWeather).

**Time features:** hour, season, year.

**Supplementary (not fed to model):** AQS method code per observation
(preserved for QC audits; renders as a supplementary table).

**Exploratory target:** AQI categorical band (Good / Moderate / USG /
Unhealthy / Very Unhealthy / Hazardous), derived per pollutant.

## Data sources

1. **TCEQ TAMIS (pollutant + on-tower met).** AQS Raw Data
   Transaction v1.6 files. Ingested via `step_01b_ingest_tceq_raw.py`
   (pollutants) and `step_02b_ingest_tceq_site_weather.py`
   (site-specific met). Preserved in `aq.pollutant_hourly` and
   `aq.site_weather_hourly`. Filtered to Coastal Bend counties in
   the `aq_coastal_bend.*` fork.
2. **OpenWeather historical API (regional met).** Hourly, single
   coordinate per major area (Nueces at 27.8045°N, 97.4316°W).
   In `aq_coastal_bend.weather_hourly`.
3. **Solcast (solar radiation).** Rolled into the weather master.
4. **HYSPLIT (backward trajectories).** NOAA/READY. Not ingested
   into Neon; run per-episode.

## Methods pipeline (5 phases)

1. **Acquisition + preprocessing.** Neon-hosted TCEQ + OpenWeather +
   site-specific met. Python-based preprocessing removes null +
   negative values, standardises units.
2. **EDA.** Distributions, correlations, pollution roses (via R
   `openair::pollutionRose`), HYSPLIT backward trajectories per
   season for elevated-SO₂ / -PM2.5 hours.
3. **Predictive modelling.** Random Forest on hourly SO₂, PM2.5, O₃.
   Two model families: (1) combined multi-pollutant model, (2)
   per-pollutant models with same features. Metrics: RMSE, MAE, R², r.
4. **Interpretation.** RF feature importance to explain *why* the
   model predicts what it does. Tests H2 + H3.
5. **Visualisation.** Site map (Figure 1) + pollution roses (Fig 4) +
   HYSPLIT trajectory-frequency surfaces (Fig 3) + observed-vs-
   predicted scatter (Fig 5) + feature-importance bar charts (Fig 6).

## Timeline (bi-weekly, always updating)

| Milestone | Target |
|---|---|
| Proposal reviewed + refined | 2026-09-20 (done) |
| Joint session with Warden + Jin | Week of 2026-10-04 |
| Analytical tibble frozen | 2026-11 |
| RF base model trained + sensitivity done | 2026-12 |
| Manuscript first draft | 2027-Q1 |
| Submission | 2027-Q2 |

**Note:** Aidan added an explicit "timeline is a living document"
note during the 2026-09-20 meeting per Dr. Melaram's earlier
guidance to not over-plan a year out.

## Analysis stack

- **Language:** Python 3.6+ (with `scikit-learn`, `pandas`, `numpy`,
  `matplotlib`, `seaborn`, `windrose`); R (with `openair`, `sf`,
  `ggplot2`, `basemaps`, `geosphere` for maps).
- **Trajectory analysis:** NOAA HYSPLIT / READY.
- **Database:** Neon Postgres (project `aged-salad-62359207`).
- **Docs:** MkDocs Material, deployed to GitHub Pages.
- **Citation management:** Zotero for interim; EndNote at publication
  (per 2026-08-12 decision).

## Prior work + literature anchors

- **Sanchez-Warren et al. (2026)** — the Melaram Lab's own prior
  Corpus Christi time-series paper (2019-2023); documents baseline
  temporal structure. This study extends by adding direction.
- **White et al. (2009)** — Cape Town refinery; wind-derived
  exposure metric predicted asthma symptoms where distance alone
  did not. Only comparable directional study in the health literature.
- **Camalier et al. (2007)** — meteorology as dominant short-term
  control on urban pollutant concentrations.
- **Zhou et al. (2023)** — Texas Gulf coast sea breeze advection of
  sulfate-rich marine air near Corpus Christi.
- **Stasio et al. (2023)** — 6 refineries in 186.5 km² Refinery Row;
  ~26 % of Texas refinery emissions; ~38k residents within 3 mi.
- **Pernak et al. (2019)** — RF for Texas air-quality forecasting.
- **Breiman (2001)** — foundational Random Forest paper.
- **Smargiassi et al. (2009)** — SO₂ from refinery stacks + asthma
  in children, Montreal. Methodological blueprint for the tabled
  health-outcome extension.
- **Carslaw & Ropkins (2012)** — `openair` R package (must-cite for
  the pollution-rose implementation).
- **Bralić / Kotsakis et al. (2024)** — Houston sea-breeze × PM2.5;
  our nearest Gulf-coast analog paper.
- **Chudnovsky et al. (2024)** — high-res PM2.5 ML prediction in
  Texas. Precedent for tree-based ensembles in this region.
