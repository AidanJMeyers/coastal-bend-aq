# Meeting Archive — One-liner + Link Per Meeting

Full write-ups live on the pipeline site at
<https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/>.

## Standing team meetings

| Date | Focus | One-line takeaway | Minutes |
|---|---|---|---|
| **2026-09-20** | Proposal review | Add Refinery-Row proximity variable + sensitivity analysis; joint Warden/Jin session week of 2026-10-04 | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-09-20/) |
| **2026-08-12** | Proposal-template working session | Bi-weekly cadence adopted; CAMS 32/34 mislabel flagged (later reconciled — was AQS/CAMS ID confusion); Dr. Niyogi (UT Austin) signal | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-08-12/) |
| **2026-07-29** | Design pivot | K-fold stacked model design; **Random Forest single-model start**; **health-outcome extension TABLED**; DSHS ED-visit data as future target-fallback | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-07-29/) |
| **2026-07-22** | Literature-scan check-in | Ecuador 2017 PM2.5 paper found; niche/mostly-novel confirmed; Aidan absent | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-07-22/) |
| **2026-07-15** | **Origin of the current project direction** | Pollution rose (Jasmine) → refinery-centered (Manasa) → ML modelling (Aidan) → grant framing (Melaram) | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-07-15/) |
| **2026-07-08** | Team PPT briefings | FRM/FEM deep-dives per pollutant lead; drop CO from first manuscript; live pipeline walkthrough | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-07-08/) |
| **2026-06-24** | Scope pivot | Full South TX → **Coastal Bend only** per Dr. Melaram; team pollutant assignments locked | [notes](https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/2026-06-24/) |

## Where to find the verbatim transcripts

Motion AI Notetaker records + summarises every meeting. Full
transcripts live in Motion (accessible via each meeting's `webUrl`
in the Motion Notes MCP response). The pipeline mirrors only the
summarised notes for privacy + brevity.

## How new meeting notes get added

Weekly cadence:

1. Meeting happens on Motion; Motion AI produces a summary + action items.
2. Aidan (or Claude via the pending scheduled task) pulls the meeting
   summary via `mcp__motion-notes__get_meeting_note`.
3. Writes it up in the pipeline's meeting-notes format at
   `pipeline/docs/meeting_notes/YYYY-MM-DD.md`.
4. Updates the dashboard JSON in
   `pipeline/docs/meeting_notes/index.md`:
   - Appends the meeting to the `meetings` array.
   - Appends new action items to the `items` array with `meeting`
     field set to the meeting date.
5. Updates the "Meeting archive" table on the same file.
6. Adds a Pipeline Updates entry.
7. Commits + pushes → GH Pages rebuilds → team sees new dashboard.

## Meetings not yet held (from the current plan)

- **2026-10-04** — interim touch-base + task-assignment sync. Aidan
  available after 2026-10-01.
- **Week of 2026-10-04** — joint session with Dr. Melaram + Dr. Jin
  + Dr. Warden. Jasmine sends Schej poll 2026-09-22.

## Related meetings not in this archive

The team also runs BREATHE-CC meetings (sibling project). Those are
tracked separately in the [`breathe-cc-documentation`](https://github.com/AidanJMeyers/breathe-cc-documentation)
repo. Occasional AQ crossover — see the "BREATHE-CC context" section
of the 2026-07-29 notes.
