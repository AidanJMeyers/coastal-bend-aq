---
name: corpus-christi-aq-wind-rose-study
description: Full context for the Corpus Christi Air Quality — Wind Rose Study (Melaram Lab, TAMU-CC). Load whenever the user asks about the Coastal Bend / Nueces / Refinery Row study, the Random-Forest × pollution-rose modelling of SO₂ + O₃ + PM2.5 at 4 monitors (2015-2025), the aq_coastal_bend Neon schema, the site_weather_hourly table, the STX AQ proposal draft, the coastal-bend-aq pipeline / GitHub / docs, team meetings, or any teammate question about how the study is set up. Also triggers on "CC AQ", "Coastal Bend AQ", "Wind Rose Study", "Refinery Row", "pollution rose", "Melaram Lab pipeline". Includes procedural instructions for teammates to connect the Neon and Motion MCP servers.
---

# Corpus Christi Air Quality — Wind Rose Study

Full-context skill for the **Melaram Lab (TAMU-CC)** Refinery-Row
directional air-quality study. Use this any time a teammate — or a
returning session — asks about the study design, the data pipeline,
the Neon database, the meeting history, or how to get set up.

## Study one-liner

> Use Random Forest with wind + meteorological covariates to predict
> the transport direction and concentration of SO₂, O₃, and PM2.5 in
> the Corpus Christi Refinery-Row area over 2015–2025, and render the
> results as pollution roses centred on the refinery corridor.

**Team leads (equal weight):** Aidan Meyers, Manasa Kuchavaram,
Jasmine Trevino.
**PI:** Dr. Rajesh Melaram.
**Health-outcome extension is TABLED** (BREATHE-CC target data
1.5–2 years out — see 2026-07-29 decision).

## Product surfaces (canonical URLs)

| Surface | Where |
|---|---|
| **Live docs site** | <https://aidanjmeyers.github.io/coastal-bend-aq/> |
| **Public GitHub** | <https://github.com/AidanJMeyers/coastal-bend-aq> |
| **Parent pipeline** (full South Texas) | <https://github.com/AidanJMeyers/south-texas-aq-pipeline> |
| **Live proposal draft (SharePoint)** | [STX AQ Proposal.docx](https://tamucc-my.sharepoint.com/:w:/r/personal/jtrevino79_islander_tamucc_edu/_layouts/15/Doc.aspx?sourcedoc=%7B1F7E1BF3-856B-46A6-8348-2B1D8BF57D76%7D&file=STX%20AQ%20Proposal.docx&action=default&mobileredirect=true&DefaultItemOpen=1&web=1) |
| **Refinery-Row scope doc** | <https://aidanjmeyers.github.io/coastal-bend-aq/proposals/refinery_row_directional_health/> |
| **Meeting-notes dashboard** | <https://aidanjmeyers.github.io/coastal-bend-aq/meeting_notes/> |
| **Pipeline changelog** | <https://aidanjmeyers.github.io/coastal-bend-aq/pipeline_updates/> |
| **Neon project** | `aged-salad-62359207` (Melaram Lab; ask Aidan for access) |
| **Neon schemas** | `aq` (full South TX), `aq_coastal_bend` (11-county filtered fork) |

## Reference files

Load whichever reference matches the current question. Do **not**
load all of them by default — this skill is meant to be lightweight.

- [`references/study_scope.md`](./references/study_scope.md) —
  research questions, hypotheses, variables, methods, timeline.
- [`references/decisions_log.md`](./references/decisions_log.md) —
  chronological log of every consequential decision made from
  2026-06-24 onward. Read this to catch up on *why* the study looks
  the way it does.
- [`references/data_inventory.md`](./references/data_inventory.md) —
  Neon schema tour: 10 tables, columns, sample queries, expected
  row counts. Includes the CAMS ↔ AQS site-ID reconciliation and
  the sites-in-scope table.
- [`references/pipeline_architecture.md`](./references/pipeline_architecture.md) —
  how the ETL pipeline works (parent south-texas-aq → filtered
  coastal-bend-aq fork), the ingest scripts + SQL DDLs, how to add a
  new data source.
- [`references/mcp_setup.md`](./references/mcp_setup.md) — teammate
  onboarding for the Neon MCP, Motion MCP, and Gmail MCP. Includes
  the fix for the local Neon MCP hang on Windows (switch to the
  remote HTTP endpoint).
- [`references/team_onboarding.md`](./references/team_onboarding.md)
  — what a new teammate should do day 1, week 1, and month 1.
- [`references/meeting_archive.md`](./references/meeting_archive.md)
  — one-line summary + link for every meeting the team has logged.
  Use this to find the meeting where a specific decision was made.
- [`references/publication_plan.md`](./references/publication_plan.md)
  — target journals, timeline, policy angle, grant reuse plan.
- [`references/related_projects.md`](./references/related_projects.md)
  — how this study relates to the parent south-texas-aq pipeline,
  the BREATHE-CC pediatric cohort, and the Dr. Niyogi (UT Austin)
  collaboration signal.

## When to use this skill vs. just search the docs site

- **Use this skill** for anything about *why* the study is designed
  this way, *who* owns which piece, *when* a decision was made, or
  *how* a teammate should set up their environment. The skill has
  the accumulated meeting context that isn't fully captured in the
  docs.
- **Use the live docs site directly** (e.g. via WebFetch) for the
  authoritative current schema, current numbers, current pollutant
  method-code details. The docs are always more current than any
  snapshot in this skill.
- **Use the Neon MCP** for anything that needs live database
  query answers.

## Quick decision anchors (2026-09-20)

- **Base model = Random Forest single-model start**, no premature
  cross-model shopping (2026-07-29 decision).
- **Wind direction encoded 3 ways in parallel** — continuous degrees,
  u/v decomposition, 16 categorical sectors (2026-08-12).
- **Site-specific TCEQ meteorology preferred** over regional Open
  Weather for the 4 monitored sites (25/26/32/34) —
  `aq_coastal_bend.site_weather_hourly`, 382,654 rows,
  2015-2025 (2026-09-20 push).
- **Refinery-Row proximity variable + sensitivity analysis over
  distance effects** now formalised as a required predictor
  (2026-09-20 decision).
- **Health-outcome extension TABLED** until BREATHE-CC cohort
  reaches 150 participants (2026-07-29 decision).
- **Joint session with Dr. Melaram + Dr. Jin + Dr. Warden**
  targeted for the week of 2026-10-04 (2026-09-20; Jasmine sends
  Schej poll 2026-09-22).

## Meta

- **Skill version:** v0.1.10 (2026-09-20).
- **Maintainer:** Aidan Meyers (`aidan.meyers@tamucc.edu`).
- **Update cadence:** bi-weekly, synced to the AQ team meeting
  cadence. If a decision is made and this skill isn't updated
  within a week, ping Aidan.
- **License:** MIT (matches the pipeline repo).
