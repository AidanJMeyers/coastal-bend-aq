---
name: scientific-paper-annotation
description: General-purpose color-coded PDF annotation workflow for any scientific paper. Given a PDF (uploaded, downloaded, or fetched), produce (a) an annotated PDF with highlights + color-coded categories + attached legend, and (b) a companion workup document (definitions, key findings, method summary, notable equations/figures, questions raised). Works standalone with a sensible default color scheme, and extends via per-project sub-skills that supply custom highlighting rubrics (e.g. cc-aq-wind-rose-study-annotation supplies rubric for the Melaram Lab CC AQ study; add more sub-skills for thesis chapters, other courses, other research groups). Triggers on "annotate this paper", "annotate this PDF", "highlight this article", "paper workup", "color-code this paper", or when the user drops a scientific PDF and asks to read/study/summarize it. Do NOT trigger for course-specific PDFs already covered by their own workup skills (e.g. CHM 350 papers use the chm-350-workup skill instead).
---

# Scientific Paper Annotation

Generalized paper-annotation workflow. Given any scientific PDF, this
skill produces a **color-coded annotated PDF + companion workup
document**. The default color scheme + workflow are enough on their
own; per-project sub-skills swap in custom highlighting rubrics that
tie annotations to specific research questions or hypotheses.

## What "annotate" means here

Two deliverables per paper:

1. **Annotated PDF** — the source PDF with:
   - **Highlights** applied to text spans, color-coded by category.
   - A **legend** attached (either as a first-page cover, a
     sidebar callout, or a companion `.md` file — user's pick).
   - Optional **margin notes / sticky notes** for anything worth
     flagging beyond a highlight.

2. **Workup document** (`.md` by default, `.docx` on request) — the
   companion synthesis:
   - Full citation + DOI + one-sentence takeaway.
   - Definitions of unfamiliar terms.
   - Key findings mapped to sections.
   - Methods summary (data source, sample size, model or measurement
     approach).
   - Notable equations, figures, tables.
   - Questions raised + connections to other work.
   - Sub-skills can specify additional workup sections (e.g. "how
     this paper relates to our hypotheses").

## When to load this skill

- User says: "annotate this paper", "highlight this article", "read
  and mark up this PDF", "do a workup on this paper", "color-code
  this for me".
- User drops a scientific PDF into the conversation and asks to
  study / summarize / prepare notes.
- User asks for a "paper review" or "literature review annotation"
  and provides one or more source PDFs.

## When NOT to use

- **CHM 350 course readings** — Aidan already has a
  `chm-350-workup` skill for those. Use it instead.
- **Non-scientific PDFs** (contracts, receipts, forms) — that's what
  `pdf-viewer:*` or `pdf-tools:*` skills do.
- **Papers where the user only wants a text summary, no PDF markup**
  — just answer inline.

## Reference files

Load whichever is relevant for the current annotation job:

- [`references/color_scheme.md`](./references/color_scheme.md) —
  the default 8-color palette + category definitions + accessibility
  notes (dark-mode safe, colorblind-friendly).
- [`references/annotation_workflow.md`](./references/annotation_workflow.md) —
  step-by-step procedure: acquire → read pass 1 → categorize →
  highlight → legend → workup.
- [`references/workup_template.md`](./references/workup_template.md) —
  markdown template for the companion workup doc. Sub-skills can
  extend this with additional sections.
- [`references/pdf_tool_setup.md`](./references/pdf_tool_setup.md) —
  which PDF MCP tools to use for reading + highlighting + writing;
  fallback approach if MCP is unavailable.
- [`references/subskill_integration.md`](./references/subskill_integration.md) —
  how a project-specific sub-skill overrides the default color scheme
  and adds custom workup sections. Read this if a matching sub-skill
  is available for the current paper.

## Available sub-skills (per project / discipline)

- **`cc-aq-wind-rose-study-annotation`** — highlighting rubric tied
  to H1-H4 hypotheses of the CC AQ Wind Rose Study (Melaram Lab).
  Load in tandem with this skill when annotating papers for that
  study.
- *(Future — Aidan will add: thesis annotation, other project
  rubrics.)*

If no matching sub-skill is loaded, fall back to the default color
scheme in `references/color_scheme.md`.

## The default 8-color scheme (quick reference)

For fast recall — full definitions in `references/color_scheme.md`.

| Color | Category | What to highlight |
|---|---|---|
| 🟨 Yellow | Study aim / thesis | The paper's own research question, aim, hypothesis |
| 🟩 Green | Methods | Study design, data source, model / method used |
| 🟧 Orange | Key findings | Main result statements, effect sizes, quantitative claims |
| 🟪 Purple | Definitions / terms | New vocabulary, jargon defined in-paper |
| 🟥 Red | Limitations / caveats | Author-flagged limitations, sample restrictions, confounders |
| 🟦 Blue | Numbers / data | Sample sizes, counts, thresholds, key numerics |
| 🟫 Brown | Prior work / citations | Cited claims worth chasing (bibliographic threads) |
| 🩶 Gray | Questions raised | Anything that prompts a follow-up question |

Sub-skills may override this palette (e.g. mapping colors to
hypotheses rather than generic categories) — the sub-skill's
scheme wins when both are loaded.

## Workflow at a glance

1. **Acquire the paper** — read the PDF metadata + first page.
2. **Load the right sub-skill if one applies** — check available
   sub-skills against the paper's topic.
3. **Read pass 1** — one-pass skim, no highlights, to get the shape.
4. **Categorize** — mentally group content into the color-scheme
   categories (default) or the sub-skill categories.
5. **Highlight pass** — apply highlights using PDF MCP tools.
6. **Attach the legend** — either as first-page cover or in the
   workup doc header.
7. **Draft the workup** — using `references/workup_template.md` as
   the starting point.
8. **Deliver** — annotated PDF + workup `.md` (or `.docx` on
   request). Save both alongside the source paper.

Full details in `references/annotation_workflow.md`.

## Meta

- **Skill version:** v0.1.0 (2026-09-20).
- **Maintainer:** Aidan Meyers (`aidan.meyers@tamucc.edu`).
- **Companion sub-skills:** `cc-aq-wind-rose-study-annotation`.
- **License:** MIT.
- **Requires:** any PDF MCP (e.g. `mcp__PDF_Tools__*` or
  `mcp__pdf-viewer__*`) for interactive annotation. Fallback:
  produce a companion `.md` with page + span references if no PDF
  MCP is available.
