# Annotation Workflow — Step by Step

The end-to-end procedure. Assumes the paper is a PDF (uploaded,
downloaded from a DOI, or fetched via a link). Alternate paths noted
where relevant.

## 0. Setup check (30 seconds)

Confirm two things before starting:

1. **Which PDF MCP is available?** Load whichever is reachable:
   `mcp__PDF_Tools__*` (preferred for highlighting + boxing),
   `mcp__pdf-viewer__*` (for interactive review), or the built-in
   `Read` tool as fallback. See `pdf_tool_setup.md`.
2. **Is a sub-skill loaded?** Check for
   `cc-aq-wind-rose-study-annotation` or another
   `*-annotation` sub-skill. If yes, use *its* color scheme +
   category rubric. If no, fall back to the default 8-color palette.

## 1. Acquire the paper

- **From a local path** — user provides a path; use `Read` /
  `mcp__PDF_Tools__read_pdf_pages` to load pages.
- **From a DOI** — construct the paywall-appropriate URL; if the user
  has institutional access, fetch via `WebFetch`. If not, ask for
  the PDF.
- **From an uploaded attachment** — use the PDF MCP's
  `get_active_document` / `list_pdfs` to locate it.
- **Metadata capture** — get title, authors, journal, year, DOI. Log
  these for the workup doc header.

## 2. Read pass 1 (~10 min for typical paper)

**Skim the whole paper, no highlights yet.** Goal: form a mental
map of the argument structure. Read at least:

- Abstract (twice — once fast, once careful).
- Section headings + first sentence of each section.
- Every figure caption + table title.
- Discussion first paragraph + last paragraph.
- Any bolded / italicised claim.

At the end of pass 1, you should be able to answer:

- What did they set out to do? (Study aim)
- What did they actually do? (Methods in one sentence)
- What did they find? (Main result in one sentence)
- What do I want to remember? (Note 3-5 things)

If the sub-skill defines project-specific questions (e.g. "how does
this map to H1-H4?"), add those to the checklist for pass 1.

## 3. Categorize (paper-level, ~3 min)

Based on pass 1, decide:

- **Which of the 8 default categories will actually appear** in
  this paper? Most papers use 4-6, not all 8. Skip categories
  that would be empty.
- **Are there 0-3 figures/tables worth boxing** as integration
  candidates? Note their page + figure numbers now.
- **Which sub-skill categories apply?** If a sub-skill is loaded
  and the paper is on-topic, expect to use most of its categories.

## 4. Highlight pass (~20-40 min)

Go through the paper in reading order. For each highlight:

- **Select the tightest span** that expresses the point. A
  full-sentence highlight is fine; a paragraph highlight is not.
- **Apply the color** for the matched category (default palette or
  sub-skill palette).
- **60% alpha** so the text underneath stays readable. The PDF MCP
  usually handles this automatically; if not, set it explicitly.
- **No highlight without a category.** If nothing in the default
  or sub-skill rubric fits, either add a margin sticky note or
  leave it un-highlighted.

**Common gotchas:**

- **Do not highlight the abstract exhaustively.** The abstract
  duplicates content from the body. Pick 2-4 highlights in the
  abstract at most — the ones that are hard to find elsewhere
  (usually the punchline + a headline number).
- **Do not highlight in figure captions unless the caption states
  a finding.** Description-only captions add noise.
- **When in doubt, do not highlight.** Sparse annotation is more
  useful to a future reader than dense annotation.

## 5. Boxed figure/table pass (~5 min)

For each figure/table pre-identified as an integration candidate in
step 3:

- **Draw a 1.5 pt dark green (`#1B5E20`) box** around the whole
  figure or table (including its caption).
- **Add a 2-5 word margin caption** to the right or bottom in the
  same color.
- **Optional `[integration:<tag>]` marker** if the sub-skill defines
  integration tags matching one of the reader's planned figures.

Example margin caption: `→ reuse layout for Fig 4 pollution rose`

See `color_scheme.md` §"Boxed figure/table annotation" for the full
spec.

## 6. Legend

Two placement options:

1. **Workup-doc header legend** (default) — a table at the top of
   the `.md` workup doc listing only the categories actually used
   in this paper. This keeps the source PDF unmodified except for
   the highlights + boxes themselves.
2. **First-page cover legend** — a small legend box inset on the
   PDF's first page. Use only if the user explicitly asks for it.

Whichever is chosen: **do not list unused categories.** A
paper that uses only 4 of the 8 default categories should show a
4-row legend, not an 8-row legend with 4 blank rows.

## 7. Workup document (~15 min)

Use `references/workup_template.md` as the starting point. Fill in:

- Header (citation, DOI, one-sentence takeaway, legend if not on the
  PDF).
- Definitions (from purple highlights).
- Key findings (from orange highlights, grouped by section).
- Methods (from green highlights).
- Notable equations / figures / tables (from any boxed annotations +
  any equation the reader will likely cite).
- Prior work threads (from brown highlights — each with the citation
  chased).
- Limitations (from red highlights).
- Questions raised (from gray highlights).
- Sub-skill extension sections (e.g. "How this maps to our
  hypotheses" — added by `cc-aq-wind-rose-study-annotation`).

Aim for **1-2 pages** for a typical 8-page paper. A workup that's
longer than the source paper defeats the purpose.

## 8. Deliver

Save both artefacts alongside the source paper. Conventional file
naming:

```
<lastname>_<year>_<short_title>.pdf              ← source
<lastname>_<year>_<short_title>.annotated.pdf   ← annotated
<lastname>_<year>_<short_title>.workup.md       ← companion doc
```

Also:

- **Confirm the annotated PDF opens cleanly** in the user's viewer
  (spot-check first page + last page).
- **Confirm the workup doc renders** as expected (headers, tables,
  legend).
- **Report to the user:** which sub-skill was loaded (or "default
  palette"), how many highlights of each color were applied, how
  many boxed annotations, and the workup-doc path.

## Time budget summary

For a typical 8-page methods paper:

| Step | Time |
|---|---|
| Setup + acquire | 2 min |
| Read pass 1 | 10 min |
| Categorize | 3 min |
| Highlight pass | 30 min |
| Boxed figure/table pass | 5 min |
| Legend | 2 min |
| Workup doc | 15 min |
| Deliver + spot-check | 3 min |
| **Total** | **~70 min** |

Shorter for editorials / commentaries; longer for methods-heavy
papers with many equations or a novel modelling framework.

## When to break the workflow

- **User asks for a text-only summary, no PDF markup** — skip
  steps 4-6 entirely, do the workup only. Answer inline.
- **PDF is scanned/image-only, no text layer** — OCR first (via a
  PDF tool with OCR) or fall back to a text-only workup with page
  references (`p.3, ¶2`).
- **Copyright-restricted PDF** — annotate for personal use only;
  do not publish or distribute the annotated version.
- **Very long paper (>30 pages, e.g. a book chapter)** — skim +
  workup only, no highlighting pass; ask the user for the specific
  sections to annotate.
