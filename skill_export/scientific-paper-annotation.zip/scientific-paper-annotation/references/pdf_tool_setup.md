# PDF Tool Setup

Which PDF MCP tools to reach for, and what to do if none of them
are available.

## Tool preferences (in priority order)

1. **`mcp__PDF_Tools__*`** — best for actually applying highlights
   + drawing boxes. Key tools:
   - `read_pdf_content` — extract text with page numbers.
   - `read_pdf_pages` — page-by-page inspection.
   - `search_pdf_text` — locate a span before highlighting.
   - `apply_text` — write margin captions, sticky notes.
   - `apply_signature` — used elsewhere; not needed here.
   - `get_page_analysis` — layout / bounding-box info for figures
     and tables. Use this to compute where to draw a box.
   - `render_pdf_page` / `render_pdf_region` — preview before + after.

2. **`mcp__pdf-viewer__*` (and `mcp__plugin_pdf-viewer_pdf__*`)** —
   interactive review with the user. Use `display_pdf` after
   annotations land so the user can confirm placement.

3. **`Read` tool (built-in)** — falls back to text extraction. Can
   read PDFs; cannot modify them. Use this when no PDF MCP is
   available; the workup doc becomes the sole deliverable.

## If no PDF-modification MCP is available

Two acceptable fallbacks:

1. **Text-only workup doc** — no annotated PDF. In the workup, use
   page + paragraph refs (`p.3, ¶2`) in place of colored
   highlights. Include a "categories used" section listing which
   default color would have been applied where. The reader can
   apply highlights themselves later in a viewer.
2. **Delegate to the user** — provide a per-page annotation script
   (a `.md` file with `p.N: [color] "quoted span" — category`
   entries). The user pastes these into Adobe / Preview / a Zotero
   annotator. Slow but works everywhere.

## Highlight color values (RGBA for PDF MCP)

The default 8-color palette in the annotation-friendly PDF format:

```
Yellow  #FFF176  RGBA(255, 241, 118, 0.6)
Green   #A5D6A7  RGBA(165, 214, 167, 0.6)
Orange  #FFB74D  RGBA(255, 183,  77, 0.6)
Purple  #CE93D8  RGBA(206, 147, 216, 0.6)
Red     #EF9A9A  RGBA(239, 154, 154, 0.6)
Blue    #90CAF9  RGBA(144, 202, 249, 0.6)
Brown   #BCAAA4  RGBA(188, 170, 164, 0.6)
Gray    #B0BEC5  RGBA(176, 190, 197, 0.6)
```

**Boxed figure/table stroke** — 1.5 pt, `#1B5E20`, no fill
(RGBA(27, 94, 32, 0.0) fill, RGBA(27, 94, 32, 1.0) stroke). Same
color for the 2-5 word margin caption in a 9-pt sans-serif.

## Order of operations (matters for some tools)

1. Read pages first — never modify without a fresh read of the target
   region.
2. Search for the exact span text (`search_pdf_text`) to get precise
   bounding coordinates.
3. Apply highlights in a single batch per page when possible — fewer
   round-trips to the MCP, less risk of index drift.
4. Draw boxes after all highlights on a page are placed.
5. Add margin captions last.
6. Re-render a preview of pages 1, mid, and last to spot-check.

## Common pitfalls

- **Multiple documents open** — some PDF MCPs are stateful about
  "the active document." Call `set_active_document` explicitly
  before each write, especially when annotating a batch of papers.
- **Read-only source PDFs** — if the source PDF has encryption or
  edit-lock flags, some MCPs refuse to write. Options: use a
  different tool that ignores the flag with user permission, or ask
  the user to unlock the copy.
- **Scanned / image PDFs** — text-selection highlights won't work.
  Fall back to boxed page regions or the text-only workup path.
- **Bounding-box drift** — figures and tables often span
  page-breaks; the box should be drawn on the primary page that
  contains the caption, with a small footnote in the workup doc
  noting the continuation page.

## After delivery

Attach both files to the conversation with `SendUserFile` (or
platform-appropriate equivalent) — the annotated PDF and the workup
`.md` — so the user can grab them without hunting for the path.
