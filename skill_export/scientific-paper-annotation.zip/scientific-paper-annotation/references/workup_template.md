# Companion Workup Template

The markdown template for the companion `.md` workup document.
Everything below the `--- COPY BELOW ---` line is the template.
Sub-skills can extend by appending additional sections.

For a typical 8-page paper, the resulting workup should be 1-2
pages. Longer isn't better.

--- COPY BELOW ---

# [Short paper title]

**Citation.** [Author, A. B., & Author, C. D. (Year). Full paper
title. *Journal Name*, Volume(Issue), Pages.]
**DOI.** <https://doi.org/…>
**Read.** [YYYY-MM-DD]
**Reader.** [Your name]
**Sub-skill applied.** [none / cc-aq-wind-rose-study-annotation /
etc.]

**One-sentence takeaway.** [What this paper adds to your working
knowledge, in one sentence you could tell a colleague.]

## Legend

Only categories actually used in this paper.

| Color | Category | Count |
|---|---|---:|
| 🟨 Yellow | Study aim / thesis | X |
| 🟩 Green | Methods | X |
| 🟧 Orange | Key findings | X |
| 🟪 Purple | Definitions | X |
| 🟦 Blue | Numbers / data | X |
| 🟫 Brown | Prior work / citations | X |
| 🟥 Red | Limitations | X |
| 🩶 Gray | Questions raised | X |
| 🟩 Dark green box | Integration candidate (figure/table) | X |

*(Sub-skill note: replace the default palette above with the
sub-skill's categories if it overrode the scheme.)*

## Study aim (from yellow highlights)

- [1-2 bullet points, verbatim or lightly paraphrased.]

## Definitions (from purple highlights)

- **Term.** [Definition as given in the paper, with page ref.]
- …

## Methods (from green highlights)

- **Study design.** [E.g. cross-sectional, retrospective cohort,
  time-series, ML modelling.]
- **Data source.** [Registry / monitor network / cohort / etc.]
- **Sample.** [N, geography, time window.]
- **Analytical approach.** [Model family, key parameters,
  validation approach.]
- **Software / stack.** [If reported.]

## Key findings (from orange highlights, grouped by section)

- **Result 1.** [Effect size, direction, uncertainty.]
- **Result 2.** …
- **Robustness / sensitivity notes.** [If applicable.]

## Notable equations, figures, tables

- **Fig. N.** [What it shows; why it matters; whether it's an
  integration candidate — if boxed, note the integration tag.]
- **Table N.** [Same.]
- **Eq. N.** [Only if the reader will cite it or reuse the
  functional form.]

**Integration candidates.** [List the figures/tables you boxed in
the annotated PDF with dark-green boxes. Include the reason and any
`[integration:<tag>]` marker.]

## Prior work threads (from brown highlights)

Citations worth chasing further.

- **[First author, year]** — [claim as attributed in the paper]. To
  read: [reason].
- …

## Limitations (from red highlights)

- [Author-flagged limitation.]
- [Reader-flagged limitation, if different.]

## Questions raised (from gray highlights)

- [Question, with page ref.]
- …

## Connections to my work

*(If a sub-skill is loaded, this section is where its integration
lives. See the sub-skill's `hypothesis_mapping.md` or equivalent
for the extension format.)*

- [How this paper relates to your project / hypothesis / RQ.]
- …

## Personal notes

Anything else worth remembering — reading conditions, mood, second
thoughts, disagreements with the authors, follow-up TODOs.

- [Note.]
- …

--- COPY ABOVE ---

## Sub-skill extension convention

A sub-skill that wants to append custom sections to this template
should specify them in its own `hypothesis_mapping.md` (or similarly
named) reference file with the following format:

```markdown
## Section title

*(added by <sub-skill-name>)*

- What the reader should fill in
- …
```

The parent skill's workflow will append those sections after the
"Connections to my work" section, in the order the sub-skill lists
them, before "Personal notes."
