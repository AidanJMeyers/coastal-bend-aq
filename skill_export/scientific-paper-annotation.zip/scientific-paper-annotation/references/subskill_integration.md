# Sub-skill Integration

How a project- or discipline-specific sub-skill layers on top of the
default annotation workflow.

## The pattern

A sub-skill (e.g. `cc-aq-wind-rose-study-annotation`) is its own
Claude Code skill folder under `~/.claude/skills/`, discoverable on
its own name. It exists to:

1. **Swap in a domain-specific highlighting rubric** (categories +
   colors) that maps to the project's hypotheses, aims, or exam
   objectives.
2. **Add project-specific integration tags** for boxed figures /
   tables (e.g. `[integration:pollution-rose-fig4]`).
3. **Append custom sections** to the companion workup document
   (e.g. "How this maps to our H1-H4 hypotheses").

The parent `scientific-paper-annotation` skill provides the
end-to-end workflow (acquire → categorize → highlight → box →
legend → workup → deliver). The sub-skill provides the *rubric* —
what to look for.

## When both are loaded

Order of precedence:

1. **Sub-skill's color scheme wins** for text highlights. Any
   category not defined by the sub-skill falls through to the
   default palette (e.g. limitations, questions raised, prior work
   threads are almost always useful and the sub-skill can keep them
   without redefining).
2. **Boxed-annotation spec is inherited** from the parent (dark
   green stroke, 1.5 pt). The sub-skill only supplies the
   `[integration:<tag>]` values.
3. **Workup template is inherited**; sub-skill's custom sections are
   appended (see below).

## Sub-skill file conventions

Each sub-skill should follow this structure:

```
~/.claude/skills/<sub-skill-name>/
├── SKILL.md                       ← frontmatter must include "sub-skill of scientific-paper-annotation" in description
├── references/
│   ├── category_rubric.md         ← what to highlight, in what color, for this domain
│   ├── hypothesis_mapping.md      ← mapping from category → project H1/H2/... or exam objective
│   ├── integration_tags.md        ← the [integration:<tag>] catalog
│   ├── workup_extensions.md       ← additional workup-doc sections + fill-in prompts
│   └── example_paper.md           ← worked example: one paper annotated end-to-end (optional but strongly recommended)
```

## Sub-skill SKILL.md frontmatter template

```yaml
---
name: <sub-skill-name>
description: Sub-skill of scientific-paper-annotation. Provides <domain>-specific highlighting rubric mapping annotations to <project>'s <hypotheses / research questions / exam objectives>. Load in tandem with scientific-paper-annotation when annotating papers for <project>. Triggers on <specific keywords>.
---
```

The description must:

- Start with "Sub-skill of scientific-paper-annotation."
- Name the domain / project.
- Name the specific keywords / paper types that should trigger it.
- Explicitly say "load in tandem with scientific-paper-annotation."

## How the workflow uses a sub-skill

Reflecting `annotation_workflow.md` §0:

- **Setup check:** scan available skills for anything matching
  `*-annotation` that isn't this parent. If a match exists AND its
  description matches the current paper's topic, load its
  `category_rubric.md`.
- **Categorize step:** use the sub-skill's rubric instead of the
  default 8 categories.
- **Legend:** render only the sub-skill's categories (plus any
  default categories the sub-skill retains).
- **Workup:** append the sub-skill's `workup_extensions.md`
  sections between "Connections to my work" and "Personal notes".

## Adding a new sub-skill (recipe)

Say you want to add one for your thesis annotation.

1. `mkdir -p ~/.claude/skills/thesis-annotation/references`
2. Write `SKILL.md` — frontmatter as above; description names the
   thesis project + trigger keywords.
3. Write `references/category_rubric.md` with 6-10 categories, each
   mapped to a color from the parent's palette (or a new hex if
   necessary — keep AAA contrast + colorblind safety).
4. Write `references/hypothesis_mapping.md` — a table mapping each
   highlight category to which thesis chapter / hypothesis it
   supports.
5. Write `references/integration_tags.md` — the catalog of
   `[integration:<tag>]` values that name your planned figures.
6. Write `references/workup_extensions.md` — the extra
   workup-doc sections and their fill-in prompts.
7. Optional but recommended: `references/example_paper.md` — one
   paper annotated end-to-end as a demonstration.
8. Package as a zip alongside the parent (see the CC AQ example).

## Companion example

Working example lives at `~/.claude/skills/cc-aq-wind-rose-study-annotation/`.

- Its rubric maps annotations to the CC AQ Wind Rose Study's H1-H4
  hypotheses.
- Its integration tags name the study's planned Figures 1-6.
- Its workup extensions include a "how this paper informs each of
  H1-H4" section.
