# Default Color Scheme + Annotation Types

The default palette for text highlights, plus a distinct **boxed
annotation** convention for whole figures + tables that stand out as
integration candidates for the reader's own work.

Sub-skills can override the categories, but should keep the boxed
figure/table convention consistent so a reader who's seen one
annotated paper can immediately parse the next.

## Two annotation types

1. **Text highlight** (default 8-color palette below) — applies to a
   span of prose. Multiple colors permitted per paragraph.
2. **Boxed figure/table annotation** — a thin rectangular border drawn
   around a whole figure or table, PLUS a short margin caption
   (2-5 words) that names *why* this figure/table earned the box.
   Reserved for "**possible integration candidate**" — a figure or
   table format we might reuse in our own manuscript or dashboard.

Text highlights and boxed annotations are complementary: highlight
the prose that describes the figure, box the figure itself.

## Default text-highlight palette (8 categories)

Chosen for AAA-contrast legibility on both light + dark PDF viewers,
and disambiguated for the two most common color-vision deficiencies
(deuteranopia + protanopia). All values are RGBA with 60 % alpha so
the underlying text remains readable.

| # | Color | Hex (RGB) | Category | What to highlight |
|---|---|---|---|---|
| 1 | 🟨 Yellow | `#FFF176` | **Study aim / thesis** | The paper's own research question, primary aim, working hypothesis. Usually 1–3 sentences in the intro + duplicated in the abstract. |
| 2 | 🟩 Green | `#A5D6A7` | **Methods** | Study design, data source, sample selection, model or measurement approach, analytical stack. Not every methods paragraph — just the sentences that describe *what they did*. |
| 3 | 🟧 Orange | `#FFB74D` | **Key findings** | Main result statements; effect sizes; quantitative claims; p-values worth noting. In the abstract, the results section, and any bold claim in the discussion. |
| 4 | 🟪 Purple | `#CE93D8` | **Definitions / terms** | New vocabulary; jargon defined in-paper; important acronym expansions on first use. |
| 5 | 🟥 Red | `#EF9A9A` | **Limitations / caveats** | Author-flagged limitations, sample restrictions, unmeasured confounders, generalizability warnings. Also: anything the reader (not the author) considers a limitation. |
| 6 | 🟦 Blue | `#90CAF9` | **Numbers / data** | Sample sizes, monitor counts, thresholds, temporal windows, key numeric summaries (means / medians / ranges). |
| 7 | 🟫 Brown | `#BCAAA4` | **Prior work / citations** | Cited claims worth chasing (bibliographic threads). Highlight the citation itself plus the sentence that describes the cited claim. |
| 8 | 🩶 Gray | `#B0BEC5` | **Questions raised** | Anything that prompts a follow-up question. Pair with a margin sticky note that states the question (2-line max). |

**Overlap rules.** If a span fits two categories (e.g. a limitation
that is also a definition), pick the more actionable one for a future
reader. A methods sentence that mentions a sample size counts as
methods; the sample size itself as a highlighted number is fine.

## Boxed figure/table annotation

Reserved category — do not use for every figure. Use only when a
figure or table is a **possible integration candidate** for the
reader's own work:

- We could reuse this **format** (chart type, axis convention, panel
  layout, legend style).
- We could **cite this figure directly** in our own manuscript's
  discussion.
- We could **extend this figure** with our own data.
- The figure holds a **methodological cue** we should imitate
  (color choice, colorbar breakpoints, projection).

Spec:

- **Border:** 1.5 pt stroke, color `#1B5E20` (dark green — distinct
  from any text-highlight color).
- **Margin caption:** 2-5 words, right or bottom margin, same dark
  green.
- **Optional sub-tag:** append a short `[integration:<tag>]` marker
  after the caption if the sub-skill defines integration tags
  (e.g. `[integration:figure-1]`, `[integration:variables-table]`).
- **Do not box every figure** — the whole point is discriminative
  attention. Aim for 0-3 boxed annotations per paper. If four or
  more would fit, use highlights + workup-doc notes instead.

## Sub-skill overrides

A per-project sub-skill (e.g. `cc-aq-wind-rose-study-annotation`)
may:

- **Replace the 8 default categories** with domain-specific ones
  (e.g. one color per hypothesis). Keep 6-10 categories max.
- **Extend the boxed-annotation spec** with additional
  integration-tag values that match its project's planned figures
  (e.g. `[integration:pollution-rose-fig4]`).
- **Keep any default categories** that still make sense (limitations,
  numbers, questions are almost always useful).

The sub-skill's scheme wins when both are loaded. When the workup
doc renders the legend, list *only* the categories actually used in
the paper — do not print unused rows.

## Accessibility notes

- All 8 default colors pass WCAG AAA when combined with black text
  at 60 % alpha over the standard PDF white.
- The palette is safe for the two most common forms of red-green
  color blindness (deuteranopia + protanopia): yellow, blue, and
  brown remain distinguishable from red + green.
- On dark-mode PDF viewers, the 60 % alpha keeps the highlights
  visible against a dark background without overwhelming the text.
- The boxed-annotation stroke color (`#1B5E20`) intentionally does
  not overlap with the text-highlight palette so a reader can
  immediately tell "this is not a highlight, this is a whole-figure
  callout."

## Rendering the legend

Two acceptable placements:

1. **First-page cover legend** — a small legend box in the top-right
   corner of page 1 (or a full first-page inset if the paper allows
   it) listing only the categories used.
2. **Workup-doc header legend** — a table at the top of the companion
   `.md` workup document. Prefer this when the annotated PDF is going
   into a shared library where the reader may not want a modified
   first page.

Default to option 2 (workup-doc header) unless the reader asks for a
cover-page legend.
